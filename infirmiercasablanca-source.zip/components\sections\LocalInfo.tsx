import { site } from "@/data/site";

type LocalInfoProps = {
  zoneName?: string;
};

export function LocalInfo({ zoneName }: LocalInfoProps) {
  const rows = [
    { label: "Qui", value: site.brandName },
    { label: "Quoi", value: "Soins infirmiers à domicile" },
    { label: "Où", value: zoneName ? `${zoneName}, Casablanca` : "Casablanca" },
    { label: "Quand", value: `Disponibilité annoncée ${site.hours.display}` },
    {
      label: "Contact",
      value: `${site.phones.mobile.display} / ${site.phones.landline.display}`,
    },
    { label: "Adresse", value: site.address.full },
  ];

  return (
    <div className="rounded-2xl border border-surface-gray-dark bg-surface-gray p-6">
      <h3 className="text-lg font-semibold text-navy-950">Informations pratiques</h3>
      <dl className="mt-4 grid gap-3 sm:grid-cols-2">
        {rows.map((row) => (
          <div key={row.label}>
            <dt className="text-xs font-semibold uppercase tracking-wide text-navy-700">
              {row.label}
            </dt>
            <dd className="text-sm text-navy-950">{row.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
