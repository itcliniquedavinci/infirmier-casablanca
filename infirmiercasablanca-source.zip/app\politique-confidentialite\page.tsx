import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { site } from "@/data/site";

const path = "/politique-confidentialite";
const title = "Politique de confidentialité";
const description =
  "Politique de confidentialité du site infirmiercasablanca.ma concernant le traitement des données personnelles.";

export const metadata = buildMetadata({ title, description, path });

export default function PolitiqueConfidentialitePage() {
  return (
    <>
      <JsonLd data={webPageSchema({ title, description, path })} />
      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: title, path }]} />

      <Container className="max-w-3xl space-y-8 py-12 text-navy-700">
        <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">{title}</h1>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Données collectées</h2>
          <p className="mt-2">
            Lorsque vous nous contactez par téléphone ou par email, nous pouvons être amenés à
            recueillir certaines informations personnelles (nom, coordonnées, informations liées à
            votre demande de soins) strictement nécessaires à l&apos;organisation de
            l&apos;intervention.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Utilisation des données</h2>
          <p className="mt-2">
            Ces informations sont utilisées uniquement pour organiser et assurer le suivi de
            l&apos;intervention demandée. Elles ne sont ni vendues, ni cédées à des tiers à des
            fins commerciales.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Conservation des données</h2>
          <p className="mt-2 text-sm italic">
            Durée de conservation à préciser par l&apos;éditeur selon ses procédures internes et la
            réglementation applicable.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Vos droits</h2>
          <p className="mt-2">
            Pour toute question relative à vos données personnelles, ou pour exercer vos droits
            d&apos;accès, de rectification ou de suppression, vous pouvez nous contacter à
            l&apos;adresse {site.email}.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Cookies</h2>
          <p className="mt-2 text-sm italic">
            À compléter si des cookies de mesure d&apos;audience ou publicitaires sont ajoutés au
            site. En l&apos;état, le site n&apos;utilise pas de cookies de suivi tiers.
          </p>
        </section>
      </Container>
    </>
  );
}
