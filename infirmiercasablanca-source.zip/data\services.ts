/**
 * ⚠️ CONTENU PLACEHOLDER À VALIDER AVANT MISE EN PRODUCTION.
 * Liste de catégories génériques de soins infirmiers à domicile.
 * Remplacez/complétez avec les actes réellement proposés par SAMUR Casablanca
 * avant publication (aucun acte médical ne doit être annoncé sans confirmation).
 */
export type Service = {
  slug: string;
  name: string;
  shortDescription: string;
  description: string;
};

export const services: Service[] = [
  {
    slug: "soins-infirmiers-courants",
    name: "Soins infirmiers courants",
    shortDescription:
      "Soins infirmiers de base réalisés à domicile sur demande.",
    description:
      "Prise en charge des soins infirmiers courants au domicile du patient, à organiser selon la prescription et la situation.",
  },
  {
    slug: "injections-perfusions",
    name: "Injections et perfusions sur prescription",
    shortDescription: "Réalisation d'injections sur prescription médicale.",
    description:
      "Administration d'injections ou de perfusions à domicile, dans le cadre d'une prescription médicale.",
  },
  {
    slug: "pansements-soins-de-plaies",
    name: "Pansements et soins de plaies",
    shortDescription: "Réfection de pansements à domicile.",
    description:
      "Réalisation et suivi de pansements à domicile, selon la prescription et l'évolution de la plaie.",
  },
  {
    slug: "surveillance-constantes",
    name: "Surveillance des constantes",
    shortDescription: "Suivi de tension, température, glycémie, etc.",
    description:
      "Prise et suivi des constantes de santé (tension artérielle, température, glycémie) à domicile.",
  },
  {
    slug: "soins-post-operatoires",
    name: "Soins post-opératoires",
    shortDescription: "Suivi infirmier après une intervention.",
    description:
      "Accompagnement infirmier à domicile dans la période suivant une intervention, selon les indications médicales.",
  },
  {
    slug: "accompagnement-personnes-agees",
    name: "Accompagnement des personnes âgées",
    shortDescription: "Soins et suivi infirmier adaptés aux personnes âgées.",
    description:
      "Soins infirmiers à domicile adaptés aux besoins des personnes âgées, en coordination avec la famille et les prescriptions médicales.",
  },
];
