import type { ReactNode } from "react";
import { site } from "@/data/site";
import { PhoneButton } from "@/components/ui/PhoneButton";
import { Container } from "@/components/ui/Container";

type HeroProps = {
  eyebrow?: string;
  title: string;
  description: string;
  secondaryCta?: { href: string; label: string };
  children?: ReactNode;
};

export function Hero({ eyebrow, title, description, secondaryCta, children }: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-navy-950">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-brand-green-600/20 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-32 left-1/3 h-72 w-72 rounded-full bg-navy-600/30 blur-3xl"
      />

      <Container className="relative grid gap-8 py-14 md:grid-cols-2 md:items-center md:py-20">
        <div>
          {eyebrow && (
            <p className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-green-500">
              {eyebrow}
            </p>
          )}
          <h1 className="text-3xl font-bold leading-tight text-white sm:text-4xl">
            {title}
          </h1>
          <p className="mt-4 max-w-xl text-base text-navy-100/90 sm:text-lg">{description}</p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
            <PhoneButton href={site.phones.mobile.href} label={`Appeler ${site.phones.mobile.display}`} />
            {secondaryCta && (
              <PhoneButton href={secondaryCta.href} label={secondaryCta.label} variant="outline-light" />
            )}
          </div>

          <p className="mt-4 text-sm text-navy-100/80">
            Également joignable au{" "}
            <a href={site.phones.landline.href} className="font-medium text-white hover:text-brand-green-500">
              {site.phones.landline.display}
            </a>{" "}
            · {site.hours.display}
          </p>
        </div>

        {children}
      </Container>
    </section>
  );
}
