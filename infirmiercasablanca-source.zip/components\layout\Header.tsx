import Link from "next/link";
import Image from "next/image";
import { site } from "@/data/site";
import { Container } from "@/components/ui/Container";
import { PhoneButton } from "@/components/ui/PhoneButton";
import { MobileNav } from "@/components/layout/MobileNav";

const navLinks = [
  { href: "/infirmier-a-domicile-casablanca", label: "Infirmier à domicile" },
  { href: "/soins-infirmiers", label: "Soins infirmiers" },
  { href: "/zones-intervention-casablanca", label: "Zones d'intervention" },
  { href: "/faq", label: "FAQ" },
  { href: "/a-propos", label: "À propos" },
  { href: "/contact", label: "Contact" },
];

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-surface-gray-dark bg-white/95 backdrop-blur">
      <div className="h-1 bg-gradient-to-r from-navy-900 via-navy-700 to-brand-green-600" />
      <Container className="relative flex h-16 items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-3 font-bold text-navy-900">
          <Image
            src="/logo.png"
            alt=""
            aria-hidden="true"
            width={48}
            height={48}
            priority
            className="h-12 w-12 shrink-0 rounded-full object-contain"
          />
          <span className="text-lg leading-tight">
            {site.brandName}
            <span className="block text-xs font-normal text-navy-700">
              Soins infirmiers à domicile
            </span>
          </span>
        </Link>

        <nav aria-label="Navigation principale" className="hidden lg:block">
          <ul className="flex items-center gap-6 text-sm font-medium text-navy-800">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="transition-colors hover:text-brand-green-600">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="hidden md:block">
          <PhoneButton href={site.phones.mobile.href} label={site.phones.mobile.display} />
        </div>

        <MobileNav links={navLinks} />
      </Container>
    </header>
  );
}
