import Link from "next/link";
import Image from "next/image";
import { site } from "@/data/site";
import { zones } from "@/data/zones";
import { Container } from "@/components/ui/Container";

const mainLinks = [
  { href: "/infirmier-a-domicile-casablanca", label: "Infirmier à domicile Casablanca" },
  { href: "/soins-infirmiers", label: "Soins infirmiers" },
  { href: "/zones-intervention-casablanca", label: "Zones d'intervention" },
  { href: "/faq", label: "FAQ" },
  { href: "/a-propos", label: "À propos" },
  { href: "/contact", label: "Contact" },
];

const legalLinks = [
  { href: "/mentions-legales", label: "Mentions légales" },
  { href: "/politique-confidentialite", label: "Politique de confidentialité" },
];

export function Footer() {
  return (
    <footer className="mt-16 border-t border-surface-gray-dark bg-navy-950 text-navy-100">
      <Container className="grid gap-10 py-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-3">
            <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-white p-1.5">
              <Image
                src="/logo.png"
                alt=""
                aria-hidden="true"
                width={48}
                height={48}
                className="h-full w-full rounded-full object-contain"
              />
            </span>
            <p className="text-lg font-bold text-white">{site.brandName}</p>
          </div>
          <p className="mt-3 text-sm text-navy-100/80">{site.legalDisclaimerName}</p>
        </div>

        <nav aria-label="Liens du site">
          <p className="text-sm font-semibold uppercase tracking-wide text-white">Le site</p>
          <ul className="mt-3 space-y-2 text-sm text-navy-100/80">
            {mainLinks.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="hover:text-brand-green-500">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Quartiers desservis">
          <p className="text-sm font-semibold uppercase tracking-wide text-white">Quartiers desservis</p>
          <ul className="mt-3 grid grid-cols-1 gap-2 text-sm text-navy-100/80">
            {zones.map((zone) => (
              <li key={zone.slug}>
                <Link
                  href={`/infirmier-a-domicile-${zone.slug}`}
                  className="hover:text-brand-green-500"
                >
                  {zone.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="text-sm font-semibold uppercase tracking-wide text-white">Contact</p>
          <ul className="mt-3 space-y-2 text-sm text-navy-100/80">
            <li>{site.address.full}</li>
            <li>
              <a href={site.phones.mobile.href} className="hover:text-brand-green-500">
                {site.phones.mobile.display}
              </a>
            </li>
            <li>
              <a href={site.phones.landline.href} className="hover:text-brand-green-500">
                {site.phones.landline.display}
              </a>
            </li>
            <li>
              <a href={`mailto:${site.email}`} className="hover:text-brand-green-500">
                {site.email}
              </a>
            </li>
            <li>{site.hours.display}</li>
          </ul>
        </div>
      </Container>

      <div className="border-t border-white/10 py-6">
        <Container className="flex flex-col items-center justify-between gap-3 text-xs text-navy-100/70 sm:flex-row">
          <p>
            © {new Date().getFullYear()} {site.brandName}. Tous droits réservés.
          </p>
          <nav aria-label="Mentions légales" className="flex gap-4">
            {legalLinks.map((link) => (
              <Link key={link.href} href={link.href} className="hover:text-brand-green-500">
                {link.label}
              </Link>
            ))}
          </nav>
        </Container>
      </div>
    </footer>
  );
}
