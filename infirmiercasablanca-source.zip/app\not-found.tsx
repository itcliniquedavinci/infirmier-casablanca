import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { PhoneButton } from "@/components/ui/PhoneButton";
import { site } from "@/data/site";

export default function NotFound() {
  return (
    <Container className="flex flex-col items-center gap-6 py-24 text-center">
      <p className="text-sm font-semibold uppercase tracking-wide text-brand-green-600">
        Erreur 404
      </p>
      <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">Page introuvable</h1>
      <p className="max-w-md text-navy-700">
        La page que vous cherchez n&apos;existe pas ou plus. Vous pouvez retourner à
        l&apos;accueil ou nous contacter directement.
      </p>
      <div className="flex flex-col gap-3 sm:flex-row">
        <Link
          href="/"
          className="inline-flex items-center justify-center rounded-full border border-navy-700 px-6 py-3 text-sm font-semibold text-navy-900 hover:bg-surface-gray"
        >
          Retour à l&apos;accueil
        </Link>
        <PhoneButton href={site.phones.mobile.href} label={`Appeler ${site.phones.mobile.display}`} />
      </div>
    </Container>
  );
}
