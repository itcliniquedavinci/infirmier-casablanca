import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { ContactCard } from "@/components/sections/ContactCard";
import { FAQSection } from "@/components/sections/FAQSection";
import { PhoneButton } from "@/components/ui/PhoneButton";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { site } from "@/data/site";
import { getFaqsForPage } from "@/data/faqs";

const path = "/contact";
const title = "Contact";
const description =
  "Contactez SAMUR Casablanca pour organiser une intervention de soins infirmiers à domicile Casablanca.";

export const metadata = buildMetadata({ title, description, path });

export default function ContactPage() {
  return (
    <>
      <JsonLd data={webPageSchema({ title, description, path })} />
      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: "Contact", path }]} />

      <Container className="grid gap-10 py-12 lg:grid-cols-2">
        <div>
          <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
          <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">Contact</h1>
          <p className="mt-4 max-w-xl text-navy-700">
            Contactez-nous par téléphone pour échanger sur votre besoin. Nous organisons
            l&apos;intervention selon votre situation et la disponibilité du service.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <PhoneButton href={site.phones.mobile.href} label={`Appeler ${site.phones.mobile.display}`} />
            <PhoneButton
              href={site.phones.landline.href}
              label={site.phones.landline.display}
              variant="secondary"
            />
          </div>
        </div>

        <ContactCard />
      </Container>

      <FAQSection
        className="bg-surface-gray py-12"
        title="Questions fréquentes sur le contact et les interventions"
        intro="Numéros, adresse, email, disponibilité et demande pour un proche."
        items={getFaqsForPage("contact")}
      />
    </>
  );
}
