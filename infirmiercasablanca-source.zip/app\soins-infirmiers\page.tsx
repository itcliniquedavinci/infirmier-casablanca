import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { CTASection } from "@/components/sections/CTASection";
import { FAQSection } from "@/components/sections/FAQSection";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { services } from "@/data/services";
import { getFaqsForPage } from "@/data/faqs";

const path = "/soins-infirmiers";
const title = "Soins infirmiers à domicile";
const description =
  "Découvrez les catégories de soins infirmiers proposées à domicile Casablanca par SAMUR Casablanca.";

export const metadata = buildMetadata({ title, description, path });

export default function SoinsInfirmiersPage() {
  return (
    <>
      <JsonLd data={webPageSchema({ title, description, path })} />
      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: title, path }]} />

      <Container className="py-12">
        <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">{title}</h1>
        <p className="mt-4 max-w-2xl text-navy-700">
          Les soins présentés ci-dessous correspondent aux catégories de soins infirmiers
          proposées à domicile. Le détail de la prise en charge est précisé avec vous lors du
          premier contact, selon la prescription et la situation.
        </p>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <div
              key={service.slug}
              className="rounded-2xl border border-surface-gray-dark bg-white p-6"
            >
              <h2 className="text-lg font-semibold text-navy-950">{service.name}</h2>
              <p className="mt-2 text-sm text-navy-700">{service.description}</p>
            </div>
          ))}
        </div>
      </Container>

      <FAQSection
        className="bg-surface-gray py-12"
        title="Questions fréquentes sur les soins infirmiers à domicile"
        intro="Ce qui peut être réalisé à domicile, le rôle de la prescription, la préparation d'un soin et le suivi régulier."
        items={getFaqsForPage("soins-infirmiers")}
        moreHref="/faq"
      />

      <CTASection />
    </>
  );
}
