import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { site } from "@/data/site";

const path = "/mentions-legales";
const title = "Mentions légales";
const description = "Mentions légales du site infirmiercasablanca.ma, édité par SAMUR Casablanca.";

export const metadata = buildMetadata({ title, description, path });

export default function MentionsLegalesPage() {
  return (
    <>
      <JsonLd data={webPageSchema({ title, description, path })} />
      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: title, path }]} />

      <Container className="max-w-3xl space-y-8 py-12 text-navy-700">
        <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">{title}</h1>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Éditeur du site</h2>
          <p className="mt-2">
            Le site {site.domain} est édité par SAMUR SARL.
            <br />
            Adresse : {site.address.full}, Maroc
            <br />
            Téléphone : {site.phones.landline.display} / {site.phones.mobile.display}
            <br />
            E-mail : {site.email}
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Nature du service</h2>
          <p className="mt-2">
            SAMUR Casablanca propose des prestations privées de soins infirmiers à domicile
            Casablanca.
          </p>
          <p className="mt-2">
            Le site {site.domain} a pour objet de présenter les services proposés par SAMUR
            Casablanca et de mettre à disposition des informations permettant de contacter le
            service.
          </p>
          <p className="mt-2">
            SAMUR Casablanca est un service privé et ne constitue pas un service public
            d&apos;urgence.
          </p>
          <p className="mt-2">
            Les informations disponibles sur ce site sont fournies à titre informatif. Elles ne
            remplacent pas une consultation, un diagnostic, une prescription ou un suivi par un
            professionnel de santé lorsque ceux-ci sont nécessaires.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Hébergement</h2>
          <p className="mt-2">
            Le site {site.domain} est hébergé par Hostinger.
            <br />
            Hébergeur : Hostinger
            <br />
            Site internet :{" "}
            <a
              href="https://www.hostinger.com"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-brand-green-600 hover:underline"
            >
              www.hostinger.com
            </a>
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Propriété intellectuelle</h2>
          <p className="mt-2">
            Les textes, éléments graphiques, logos, images et autres contenus présents sur{" "}
            {site.domain} sont protégés par les règles applicables en matière de propriété
            intellectuelle, sous réserve des droits appartenant à des tiers.
          </p>
          <p className="mt-2">
            Toute reproduction, représentation, modification ou utilisation non autorisée de ces
            contenus est interdite, sauf autorisation préalable du titulaire des droits concerné.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-navy-950">Responsabilité</h2>
          <p className="mt-2">
            SAMUR Casablanca s&apos;efforce de fournir des informations exactes et à jour sur le
            site. Toutefois, les informations publiées sont fournies à titre informatif et peuvent
            être modifiées ou mises à jour.
          </p>
          <p className="mt-2">
            L&apos;utilisation des informations disponibles sur le site ne saurait se substituer à
            l&apos;avis d&apos;un professionnel de santé lorsque celui-ci est nécessaire.
          </p>
        </section>
      </Container>
    </>
  );
}
