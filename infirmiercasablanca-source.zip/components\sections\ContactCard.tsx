import { site } from "@/data/site";

export function ContactCard() {
  return (
    <div className="rounded-2xl border border-surface-gray-dark bg-white p-6">
      <h3 className="text-lg font-semibold text-navy-950">Nous contacter</h3>
      <dl className="mt-4 space-y-3 text-sm text-navy-700">
        <div>
          <dt className="font-medium text-navy-900">Adresse</dt>
          <dd>{site.address.full}</dd>
        </div>
        <div>
          <dt className="font-medium text-navy-900">Téléphone mobile</dt>
          <dd>
            <a href={site.phones.mobile.href} className="hover:text-brand-green-600">
              {site.phones.mobile.display}
            </a>
          </dd>
        </div>
        <div>
          <dt className="font-medium text-navy-900">Téléphone fixe</dt>
          <dd>
            <a href={site.phones.landline.href} className="hover:text-brand-green-600">
              {site.phones.landline.display}
            </a>
          </dd>
        </div>
        <div>
          <dt className="font-medium text-navy-900">Email</dt>
          <dd>
            <a href={`mailto:${site.email}`} className="hover:text-brand-green-600">
              {site.email}
            </a>
          </dd>
        </div>
        <div>
          <dt className="font-medium text-navy-900">Horaires</dt>
          <dd>{site.hours.display}</dd>
        </div>
      </dl>
    </div>
  );
}
