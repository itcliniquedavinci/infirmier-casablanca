/**
 * Redirections 301 depuis les anciennes URLs indexées de infirmiercasablanca.ma.
 * À compléter à partir de l'inventaire réel (sitemap / export Google Search Console
 * de l'ancien site) avant mise en production, afin d'éviter toute perte de SEO
 * (voir README - section "Migration SEO").
 *
 * Format attendu par next.config.ts :
 * { source: "/ancienne-url", destination: "/nouvelle-url", permanent: true }
 */
export type RedirectRule = {
  source: string;
  destination: string;
  permanent: boolean;
};

export const redirects: RedirectRule[] = [
  // Exemple (à adapter avec les vraies anciennes URLs) :
  // { source: "/services/infirmier-domicile", destination: "/infirmier-a-domicile-casablanca", permanent: true },
];
