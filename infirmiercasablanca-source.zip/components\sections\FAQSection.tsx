import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { FAQAccordion } from "@/components/sections/FAQAccordion";
import { JsonLd } from "@/components/schema/JsonLd";
import { faqPageSchema } from "@/lib/schema";
import type { FaqItem } from "@/data/faqs";
import { cn } from "@/lib/utils";

type FAQSectionProps = {
  title: string;
  items: FaqItem[];
  intro?: string;
  moreHref?: string;
  moreLabel?: string;
  /** Injecte le JSON-LD FAQPage à partir des mêmes items visibles. Défaut : true. */
  withSchema?: boolean;
  /** Classe utilitaire de fond/espacement pour la <section>. */
  className?: string;
  /** Rend la section sans <Container> (utile dans une grille déjà contrainte). */
  bare?: boolean;
};

/**
 * Section FAQ réutilisable (Server Component).
 * Le texte des réponses est présent dans le HTML rendu ; seul l'accordéon
 * (ouverture/fermeture) dépend du JavaScript.
 */
export function FAQSection({
  title,
  items,
  intro,
  moreHref,
  moreLabel = "Voir toutes les questions fréquentes",
  withSchema = true,
  className = "py-12",
  bare = false,
}: FAQSectionProps) {
  if (items.length === 0) return null;

  const body = (
    <>
      <h2 className="text-2xl font-bold text-navy-950">{title}</h2>
      {intro ? <p className="mt-3 max-w-2xl text-navy-700">{intro}</p> : null}
      <div className="mt-8">
        <FAQAccordion items={items} />
      </div>
      {moreHref ? (
        <Link
          href={moreHref}
          className="mt-6 inline-block text-sm font-semibold text-brand-green-600 hover:underline"
        >
          {moreLabel} →
        </Link>
      ) : null}
    </>
  );

  return (
    <section className={cn(className)}>
      {withSchema ? <JsonLd data={faqPageSchema(items)} /> : null}
      {bare ? body : <Container>{body}</Container>}
    </section>
  );
}
