"use client";

import { useState } from "react";
import type { FaqItem } from "@/data/faqs";
import { cn } from "@/lib/utils";

export function FAQAccordion({
  items,
  defaultOpenIndex = 0,
}: {
  items: FaqItem[];
  defaultOpenIndex?: number | null;
}) {
  const [openIndex, setOpenIndex] = useState<number | null>(defaultOpenIndex);

  return (
    <div className="divide-y divide-surface-gray-dark rounded-2xl border border-surface-gray-dark bg-white">
      {items.map((item, index) => {
        const isOpen = openIndex === index;
        const panelId = `faq-panel-${index}`;
        const buttonId = `faq-button-${index}`;

        return (
          <div key={`${index}-${item.question}`}>
            <h3>
              <button
                id={buttonId}
                type="button"
                aria-expanded={isOpen}
                aria-controls={panelId}
                onClick={() => setOpenIndex(isOpen ? null : index)}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-medium text-navy-950"
              >
                {item.question}
                <span
                  aria-hidden="true"
                  className={cn(
                    "shrink-0 text-navy-700 transition-transform",
                    isOpen && "rotate-45"
                  )}
                >
                  +
                </span>
              </button>
            </h3>
            <div
              id={panelId}
              role="region"
              aria-labelledby={buttonId}
              hidden={!isOpen}
              className="px-5 pb-4 text-sm text-navy-700"
            >
              {item.answer}
            </div>
          </div>
        );
      })}
    </div>
  );
}
