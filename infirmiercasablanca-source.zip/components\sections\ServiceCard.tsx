import type { Service } from "@/data/services";

export function ServiceCard({ service }: { service: Service }) {
  return (
    <div className="rounded-2xl border border-surface-gray-dark bg-white p-6 shadow-sm transition-shadow hover:shadow-md">
      <h3 className="text-lg font-semibold text-navy-950">{service.name}</h3>
      <p className="mt-2 text-sm text-navy-700">{service.shortDescription}</p>
    </div>
  );
}
