export const site = {
  brandName: "SAMUR Casablanca",
  legalDisclaimerName:
    "SAMUR Casablanca est un service privé de soins infirmiers à domicile. Il ne s'agit pas d'un service public d'urgence ni d'une structure hospitalière.",
  domain: "infirmiercasablanca.ma",
  url: "https://infirmiercasablanca.ma",
  tagline: "Soins infirmiers à domicile Casablanca",
  description:
    "Service de soins infirmiers à domicile Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7.",
  address: {
    street: "343 Rue Mostafa El Maani",
    city: "Casablanca",
    postalCode: "",
    region: "Casablanca-Settat",
    country: "MA",
    full: "343 Rue Mostafa El Maani, Casablanca",
  },
  phones: {
    mobile: {
      display: "06 61 30 15 34",
      href: "tel:+212661301534",
    },
    landline: {
      display: "05 22 98 16 16",
      href: "tel:+212522981616",
    },
  },
  whatsapp: {
    display: "06 61 30 15 34",
    href: "https://wa.me/212661301534",
  },
  email: "urgencesamur@gmail.com",
  hours: {
    display: "24h/24 – 7j/7",
    schemaOpens: "00:00",
    schemaCloses: "23:59",
  },
  socials: {
    // À compléter si des comptes existent réellement (aucun lien inventé).
  },
  serviceArea: "Casablanca",
} as const;

export const legalMentions = {
  editorName: "",
  legalForm: "",
  rc: "",
  ice: "",
  publicationDirector: "",
  hostName: "",
  hostAddress: "",
  hostContact: "",
} as const;
