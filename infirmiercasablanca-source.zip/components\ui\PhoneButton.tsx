import { cn } from "@/lib/utils";

type PhoneButtonProps = {
  href: string;
  label: string;
  variant?: "primary" | "secondary" | "ghost" | "outline-light";
  className?: string;
};

export function PhoneButton({
  href,
  label,
  variant = "primary",
  className,
}: PhoneButtonProps) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2";

  const variants = {
    primary: "bg-brand-green-600 text-white hover:bg-brand-green-500",
    secondary: "bg-navy-900 text-white hover:bg-navy-800",
    ghost: "border border-navy-700 text-navy-900 hover:bg-surface-gray",
    "outline-light": "border border-white/50 text-white hover:bg-white/10",
  };

  return (
    <a href={href} className={cn(base, variants[variant], className)}>
      <PhoneIcon />
      {label}
    </a>
  );
}

function PhoneIcon() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      className="h-4 w-4"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M2.5 4.5c0-1.1.9-2 2-2h2.153a1 1 0 0 1 .986.836l.58 3.478a1 1 0 0 1-.54 1.06l-1.6.8a12.06 12.06 0 0 0 5.747 5.747l.8-1.6a1 1 0 0 1 1.06-.54l3.478.58a1 1 0 0 1 .836.986V16.5a2 2 0 0 1-2 2h-1c-8 0-14.5-6.5-14.5-14.5v-1Z"
      />
    </svg>
  );
}
