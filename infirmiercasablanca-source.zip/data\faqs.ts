/**
 * Source unique des FAQ du site (SEO + GEO).
 *
 * Règles appliquées :
 * - Chaque FAQ est rattachée à la (aux) page(s) où elle est la plus pertinente
 *   via `pages` ; elle n'est rendue nulle part ailleurs.
 * - Seules les entrées `status: "published"` sont affichées et injectées dans le
 *   JSON-LD `FAQPage`. Les entrées `a-confirmer` / `draft` restent invisibles
 *   tant que l'information n'est pas validée (cf. AGENTS.md — exactitude médicale).
 * - Aucune information non vérifiable : pas de tarif chiffré, pas de délai promis,
 *   pas de laboratoire / partenaire / acte médical inventé.
 *
 * Clés de page utilisées dans `pages` :
 *   "home" | "pilier" | "soins-infirmiers" | "zones" | "contact"
 *   "zone:<slug>"      (ex. "zone:maarif") pour les pages quartier
 *   "service:<slug>"   (ex. "service:pansement") — pages non créées à ce jour
 */

export type FaqItem = {
  question: string;
  answer: string;
};

export type FaqStatus = "published" | "a-confirmer" | "draft";

export type FaqCategory =
  | "infirmier-domicile"
  | "soins-infirmiers"
  | "avant-intervention"
  | "ordonnances"
  | "pansements"
  | "injections"
  | "perfusions"
  | "prises-de-sang"
  | "personnes-agees"
  | "apres-hospitalisation"
  | "horaires"
  | "tarifs"
  | "zones"
  | "contact"
  | "urgences";

export type FaqEntry = FaqItem & {
  id: string;
  category: FaqCategory;
  pages: string[];
  service: string | null;
  zone: string | null;
  status: FaqStatus;
  /** Sélectionnée pour le hub thématique /faq (évite de répéter les FAQ locales). */
  hub?: boolean;
};

export const FAQ_CATEGORY_LABELS: Record<FaqCategory, string> = {
  "infirmier-domicile": "Infirmier à domicile",
  "soins-infirmiers": "Soins infirmiers",
  "avant-intervention": "Avant l'intervention",
  ordonnances: "Ordonnances et prescriptions",
  pansements: "Pansements",
  injections: "Injections",
  perfusions: "Perfusions",
  "prises-de-sang": "Prises de sang",
  "personnes-agees": "Personnes âgées",
  "apres-hospitalisation": "Après hospitalisation",
  horaires: "Horaires et disponibilité",
  tarifs: "Tarifs",
  zones: "Zones de Casablanca",
  contact: "Contact",
  urgences: "Urgences et sécurité",
};

/** Ordre d'affichage des catégories dans le hub /faq. */
export const FAQ_HUB_ORDER: FaqCategory[] = [
  "infirmier-domicile",
  "soins-infirmiers",
  "avant-intervention",
  "ordonnances",
  "pansements",
  "injections",
  "perfusions",
  "prises-de-sang",
  "personnes-agees",
  "apres-hospitalisation",
  "horaires",
  "tarifs",
  "zones",
  "contact",
  "urgences",
];

export const faqs: FaqEntry[] = [
  // ─────────────────────────────────────────────────────────────
  // ACCUEIL  ("home")
  // ─────────────────────────────────────────────────────────────
  {
    id: "home-demander-infirmier",
    category: "infirmier-domicile",
    pages: ["home"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question: "Comment demander un infirmier à domicile Casablanca ?",
    answer:
      "Pour demander un infirmier à domicile Casablanca, contactez SAMUR Casablanca par téléphone au 06 61 30 15 34 ou au 05 22 98 16 16. Un premier échange permet de préciser le soin recherché, l'adresse et la situation. L'intervention est ensuite organisée selon le besoin exprimé et la disponibilité du service au moment de l'appel.",
  },
  {
    id: "home-soins-possibles",
    category: "soins-infirmiers",
    pages: ["home"],
    service: null,
    zone: null,
    status: "published",
    question: "Quels soins infirmiers peuvent être réalisés à domicile ?",
    answer:
      "De nombreux soins infirmiers courants peuvent être réalisés au domicile du patient, sur prescription médicale lorsque celle-ci est requise. Le type de soin réalisable dépend de la situation et des indications du médecin. Le détail est précisé lors du premier contact avec SAMUR Casablanca. La page Soins infirmiers présente les catégories de soins organisées à domicile Casablanca.",
  },
  {
    id: "home-disponibilite-247",
    category: "horaires",
    pages: ["home"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Le service de soins infirmiers est-il disponible 24h/24 et 7j/7 ?",
    answer:
      "La disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7. Chaque demande est organisée en fonction de la situation et des disponibilités au moment de l'appel. Il est donc conseillé d'appeler dès que le besoin est identifié afin de planifier l'intervention dans les meilleures conditions.",
  },
  {
    id: "home-zones",
    category: "zones",
    pages: ["home"],
    service: null,
    zone: "casablanca",
    status: "published",
    question: "Dans quelles zones de Casablanca le service intervient-il ?",
    answer:
      "SAMUR Casablanca organise des soins infirmiers à domicile Casablanca, notamment dans les quartiers de Maarif, Gauthier, Racine, Bourgogne, Anfa, Ain Diab, Oasis, Californie et Sidi Maarouf. Si votre quartier n'est pas mentionné, un appel permet de vérifier si l'intervention peut être organisée à votre adresse.",
  },
  {
    id: "home-ordonnance",
    category: "ordonnances",
    pages: ["home"],
    service: null,
    zone: null,
    status: "published",
    question: "Une ordonnance est-elle nécessaire pour certains soins infirmiers ?",
    answer:
      "Certains soins infirmiers nécessitent une prescription médicale, d'autres non, selon leur nature. Lorsqu'une ordonnance existe, il est utile de la préparer avant l'intervention et de la présenter à l'infirmier. En cas de doute, le plus simple est d'indiquer le soin recherché lors de l'appel à SAMUR Casablanca, qui précisera si une prescription est requise.",
  },
  {
    id: "home-proche",
    category: "avant-intervention",
    pages: ["home"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Peut-on demander des soins à domicile pour un proche ?",
    answer:
      "Oui, une demande de soins à domicile peut être faite pour un proche : parent, conjoint, personne âgée ou toute personne de l'entourage. Il suffit de contacter SAMUR Casablanca en indiquant la situation, l'adresse à Casablanca et le soin concerné. La présence d'un membre de la famille lors de la première intervention est souvent utile.",
  },
  {
    id: "home-tarif",
    category: "tarifs",
    pages: ["home"],
    service: null,
    zone: null,
    status: "published",
    question: "Comment connaître le tarif d'une intervention ?",
    answer:
      "Le tarif d'une intervention dépend du type de soin, de sa durée et de la fréquence des passages. Aucun montant standard n'est communiqué à l'avance : il est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu. Pensez à décrire précisément le soin recherché pour obtenir une information adaptée.",
  },
  {
    id: "home-numero",
    category: "contact",
    pages: ["home"],
    service: null,
    zone: null,
    status: "published",
    question: "Quel numéro appeler pour contacter le service ?",
    answer:
      "Pour contacter SAMUR Casablanca, appelez le 06 61 30 15 34 (mobile) ou le 05 22 98 16 16 (fixe). Le service est également joignable par email à urgencesamur@gmail.com. L'adresse à Casablanca est le 343 Rue Mostafa El Maani. En cas d'urgence vitale, il faut contacter les services d'urgence officiels.",
  },

  // ─────────────────────────────────────────────────────────────
  // PAGE PILIER  ("pilier")
  // ─────────────────────────────────────────────────────────────
  {
    id: "pilier-faire-venir",
    category: "infirmier-domicile",
    pages: ["pilier"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question:
      "Comment faire venir un infirmier à domicile Casablanca, et quel service contacter ?",
    answer:
      "Pour faire venir un infirmier à domicile Casablanca, contactez SAMUR Casablanca, service privé de soins infirmiers à domicile, au 06 61 30 15 34 ou au 05 22 98 16 16. Lors de l'appel, vous décrivez le soin recherché, l'adresse et la situation. L'intervention est organisée selon le besoin et la disponibilité. Ce service est distinct des services publics d'urgence.",
  },
  {
    id: "pilier-deroulement",
    category: "avant-intervention",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Comment se déroule une intervention infirmière à domicile ?",
    answer:
      "Une intervention infirmière à domicile commence par un contact téléphonique qui précise le soin, l'adresse et le contexte. L'infirmier se rend ensuite au domicile du patient à Casablanca, à l'horaire convenu, réalise le soin prévu, puis explique le suivi éventuel. Si une prescription encadre le soin, elle est consultée sur place. Plusieurs passages peuvent être planifiés si nécessaire.",
  },
  {
    id: "pilier-soins-domicile-casa",
    category: "soins-infirmiers",
    pages: ["pilier"],
    service: null,
    zone: "casablanca",
    status: "published",
    question: "Quels soins infirmiers peuvent être réalisés à domicile Casablanca ?",
    answer:
      "Les soins infirmiers courants peuvent généralement être réalisés à domicile Casablanca, sur prescription lorsque celle-ci est nécessaire. Le caractère réalisable d'un soin au domicile dépend de la situation du patient et des indications médicales. Le détail des soins organisés par SAMUR Casablanca est présenté sur la page Soins infirmiers et précisé lors du premier appel.",
  },
  {
    id: "pilier-quartiers",
    category: "zones",
    pages: ["pilier"],
    service: null,
    zone: "casablanca",
    status: "published",
    question: "Quels quartiers de Casablanca sont desservis ?",
    answer:
      "SAMUR Casablanca intervient à Casablanca, en particulier à Maarif, Gauthier, Racine, Bourgogne, Anfa, Ain Diab, Oasis, Californie et Sidi Maarouf. D'autres secteurs de la ville peuvent être concernés : un appel permet de confirmer si une intervention est possible à votre adresse. La liste complète figure sur la page Zones d'intervention.",
  },
  {
    id: "pilier-nuit",
    category: "horaires",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Peut-on demander une intervention infirmière la nuit ?",
    answer:
      "La disponibilité annoncée par SAMUR Casablanca est de 24h/24, y compris la nuit. Chaque demande nocturne est organisée selon la situation et les disponibilités au moment de l'appel. Pour un besoin la nuit, il est préférable d'appeler dès qu'il est identifié afin de planifier le passage. En cas d'urgence vitale, contactez les services d'urgence officiels.",
  },
  {
    id: "pilier-dimanche",
    category: "horaires",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Le service est-il disponible le dimanche et les jours fériés ?",
    answer:
      "La disponibilité annoncée est de 7j/7, dimanche et jours fériés inclus. Comme en semaine, l'intervention est organisée en fonction de la situation et des disponibilités au moment de la demande. Il est conseillé de contacter SAMUR Casablanca à l'avance lorsque le besoin est prévisible, par exemple pour un soin régulier le week-end.",
  },
  {
    id: "pilier-programmer",
    category: "avant-intervention",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    question: "Peut-on programmer une intervention à l'avance ?",
    answer:
      "Oui, une intervention peut être programmée à l'avance. Lors de l'appel, vous indiquez la date, l'horaire souhaité et le soin concerné ; le passage est alors planifié selon les disponibilités. Programmer à l'avance est utile pour les soins réguliers ou pour préparer un retour à domicile après une hospitalisation à Casablanca.",
  },
  {
    id: "pilier-jour-meme",
    category: "avant-intervention",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    question: "Peut-on demander une intervention le jour même ?",
    answer:
      "Une demande d'intervention le jour même est possible, sans garantie de créneau : la faisabilité dépend de la situation et des disponibilités au moment de l'appel. Plus la demande est faite tôt dans la journée, plus l'organisation est simple. Pour un besoin planifiable, il est préférable de contacter SAMUR Casablanca à l'avance.",
  },
  {
    id: "pilier-ordonnance",
    category: "ordonnances",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    question: "Une ordonnance est-elle nécessaire pour des soins infirmiers à domicile ?",
    answer:
      "Cela dépend du soin : certains actes infirmiers nécessitent une prescription médicale, d'autres non. Lorsqu'une ordonnance existe, elle doit être disponible lors de l'intervention et présentée à l'infirmier. Si vous ignorez si une prescription est requise pour le soin recherché, indiquez-le lors de l'appel à SAMUR Casablanca, qui vous le précisera.",
  },
  {
    id: "pilier-preparer",
    category: "avant-intervention",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Que faut-il préparer avant le passage d'un infirmier ?",
    answer:
      "Avant le passage d'un infirmier, il est utile de préparer l'ordonnance et les documents médicaux liés au soin, ainsi que les traitements déjà en cours. Prévoyez un espace propre et accessible, et la présence d'un proche si le patient a besoin d'aide. Les besoins précis de préparation sont indiqués lors de l'échange téléphonique.",
  },
  {
    id: "pilier-plusieurs-passages",
    category: "avant-intervention",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    question: "Peut-on organiser plusieurs passages infirmiers à domicile ?",
    answer:
      "Oui, plusieurs passages infirmiers peuvent être organisés à domicile, par exemple pour un soin quotidien ou un suivi sur plusieurs jours. La fréquence et la durée sont définies avec SAMUR Casablanca selon la prescription et l'évolution de la situation. Un calendrier de passages peut être mis en place à Casablanca lors de la prise de contact.",
  },
  {
    id: "pilier-personne-agee",
    category: "personnes-agees",
    pages: ["pilier"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question:
      "Peut-on demander des soins infirmiers pour une personne âgée à Casablanca ?",
    answer:
      "Oui, des soins infirmiers à domicile peuvent être organisés pour une personne âgée à Casablanca, à sa demande ou à celle d'un proche. L'intervention se fait au domicile ou au lieu de résidence habituel de la personne. Lors de l'appel à SAMUR Casablanca, précisez la situation, l'autonomie de la personne et les soins prescrits.",
  },
  {
    id: "pilier-apres-hospitalisation",
    category: "apres-hospitalisation",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Peut-on organiser des soins infirmiers après une hospitalisation ?",
    answer:
      "Oui, des soins infirmiers à domicile peuvent être organisés après une hospitalisation, dans le prolongement des prescriptions remises à la sortie. Il est possible de préparer l'organisation avant même le retour à domicile Casablanca. Munissez-vous du compte rendu d'hospitalisation et des ordonnances, puis contactez SAMUR Casablanca pour planifier les passages nécessaires.",
  },
  {
    id: "pilier-tarif",
    category: "tarifs",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Comment connaître le tarif d'une intervention infirmière à domicile ?",
    answer:
      "Le tarif dépend du type de soin, de sa durée et du nombre de passages. Aucune grille n'est diffusée à l'avance : le montant est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu. Décrire précisément le soin et sa fréquence permet d'obtenir une information adaptée à votre situation.",
  },
  {
    id: "pilier-numero",
    category: "contact",
    pages: ["pilier"],
    service: null,
    zone: "casablanca",
    status: "published",
    question:
      "Quel numéro appeler pour demander un infirmier à domicile Casablanca ?",
    answer:
      "Pour demander un infirmier à domicile Casablanca, appelez SAMUR Casablanca au 06 61 30 15 34 ou au 05 22 98 16 16. Le service répond aussi par email à urgencesamur@gmail.com et son adresse est le 343 Rue Mostafa El Maani, Casablanca. Pour une urgence vitale, composez le numéro des services d'urgence officiels.",
  },
  {
    id: "pilier-vs-urgence",
    category: "urgences",
    pages: ["pilier"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question:
      "Les soins infirmiers à domicile remplacent-ils un service d'urgence médicale ?",
    answer:
      "Non. Les soins infirmiers à domicile ne remplacent pas un service d'urgence médicale. SAMUR Casablanca est un service privé de soins infirmiers à domicile, distinct du SAMU public et des structures hospitalières. En cas d'urgence vitale — détresse respiratoire, douleur thoracique, perte de connaissance, hémorragie —, il faut appeler immédiatement les services d'urgence officiels.",
  },

  // ─────────────────────────────────────────────────────────────
  // SOINS INFIRMIERS  ("soins-infirmiers")
  // ─────────────────────────────────────────────────────────────
  {
    id: "soins-quels-soins",
    category: "soins-infirmiers",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Quels soins infirmiers peuvent être réalisés à domicile ?",
    answer:
      "De nombreux soins infirmiers courants peuvent être réalisés à domicile lorsqu'ils ne nécessitent pas d'équipement hospitalier ni de surveillance continue. La liste exacte dépend de la prescription et de l'état du patient. SAMUR Casablanca organise ces soins au domicile à Casablanca et en précise le cadre lors du premier contact. Les soins plus complexes relèvent d'une structure adaptée.",
  },
  {
    id: "soins-savoir-si-domicile",
    category: "soins-infirmiers",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Comment savoir si un soin peut être réalisé à domicile ?",
    answer:
      "Pour savoir si un soin peut être réalisé à domicile, le mieux est de se référer à la prescription médicale et d'en parler avec SAMUR Casablanca lors de l'appel. La faisabilité dépend de la nature du soin, du matériel requis et de l'état de la personne. Le médecin prescripteur reste l'interlocuteur de référence en cas de doute médical.",
  },
  {
    id: "soins-prescription-requise",
    category: "ordonnances",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Quels soins nécessitent une prescription médicale ?",
    answer:
      "Les soins qui impliquent l'administration d'un médicament, un acte technique ou un suivi encadré nécessitent généralement une prescription médicale. D'autres soins d'hygiène ou de confort peuvent en être dispensés. La prescription précise le soin, sa fréquence et sa durée. En cas de doute sur le soin recherché, indiquez-le lors de l'appel à SAMUR Casablanca.",
  },
  {
    id: "soins-ordonnance-tous",
    category: "ordonnances",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Une ordonnance est-elle nécessaire pour tous les soins infirmiers ?",
    answer:
      "Non, une ordonnance n'est pas nécessaire pour tous les soins infirmiers, mais elle l'est pour une grande partie des actes techniques et pour tout soin impliquant un médicament. Lorsqu'elle existe, l'ordonnance doit être présentée à l'infirmier lors de l'intervention. Si vous n'êtes pas sûr, précisez le soin souhaité lors du contact avec SAMUR Casablanca.",
  },
  {
    id: "soins-preparer",
    category: "avant-intervention",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    question: "Que faut-il préparer avant un soin infirmier à domicile ?",
    answer:
      "Avant un soin infirmier à domicile, préparez l'ordonnance et les documents médicaux liés au soin, la liste des traitements en cours, et un espace propre et bien éclairé. Prévoyez la présence d'un proche si la personne a besoin d'assistance. Les éléments spécifiques à réunir sont indiqués lors de l'échange téléphonique avec SAMUR Casablanca.",
  },
  {
    id: "soins-plusieurs-meme-passage",
    category: "avant-intervention",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Peut-on organiser plusieurs soins lors d'un même passage ?",
    answer:
      "Oui, plusieurs soins peuvent parfois être réalisés lors d'un même passage, si leur nature et le temps disponible le permettent. Cela est précisé au moment de la prise de rendez-vous avec SAMUR Casablanca, en fonction des prescriptions. Regrouper des soins compatibles évite des déplacements supplémentaires au domicile à Casablanca.",
  },
  {
    id: "soins-reguliers",
    category: "soins-infirmiers",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Peut-on programmer des soins infirmiers réguliers à domicile ?",
    answer:
      "Oui, des soins infirmiers réguliers peuvent être programmés à domicile, par exemple quotidiens ou plusieurs fois par semaine. La fréquence suit la prescription et l'évolution de la situation. Un calendrier de passages est défini avec SAMUR Casablanca lors de la mise en place, puis ajusté si le besoin change.",
  },
  {
    id: "soins-apres-hopital",
    category: "apres-hospitalisation",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    question: "Peut-on organiser des soins après une sortie d'hôpital ?",
    answer:
      "Oui, des soins infirmiers à domicile peuvent être organisés après une sortie d'hôpital ou de clinique, sur la base des prescriptions de sortie. L'organisation peut être préparée avant le retour au domicile à Casablanca. Le compte rendu d'hospitalisation et les ordonnances permettent de définir les passages nécessaires avec SAMUR Casablanca.",
  },
  {
    id: "soins-personne-agee",
    category: "personnes-agees",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    question: "Peut-on organiser des soins à domicile pour une personne âgée ?",
    answer:
      "Oui, des soins infirmiers à domicile peuvent être organisés pour une personne âgée, à sa demande ou à celle d'un proche. Les passages ont lieu à son domicile ou lieu de résidence habituel à Casablanca. Lors du contact avec SAMUR Casablanca, précisez le degré d'autonomie de la personne et les soins prescrits.",
  },
  {
    id: "soins-materiel",
    category: "avant-intervention",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    question: "Qui fournit le matériel nécessaire au soin ?",
    answer:
      "La fourniture du matériel dépend du soin et de ce que prévoit la prescription : certains dispositifs sont délivrés en pharmacie sur ordonnance, d'autres sont apportés par l'infirmier. Ce point est clarifié lors de l'échange téléphonique avec SAMUR Casablanca, avant l'intervention, afin que rien ne manque le jour du soin.",
  },
  {
    id: "soins-soir-weekend",
    category: "horaires",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    question: "Peut-on demander des soins le soir ou le week-end ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, ce qui inclut le soir et le week-end. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel. Pour un soin récurrent en soirée ou le week-end, il est préférable de le planifier à l'avance.",
  },
  {
    id: "soins-avis-medical",
    category: "urgences",
    pages: ["soins-infirmiers"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question:
      "Quand faut-il demander un avis médical plutôt qu'un soin infirmier à domicile ?",
    answer:
      "Un avis médical est nécessaire lorsque l'état de santé se modifie de façon inattendue : fièvre élevée, douleur nouvelle ou intense, plaie qui s'aggrave, essoufflement, malaise. Dans ces cas, il faut contacter un médecin, et les services d'urgence officiels en cas d'urgence vitale. Les soins infirmiers à domicile s'inscrivent dans un cadre prescrit et ne remplacent pas une consultation médicale.",
  },

  // ─────────────────────────────────────────────────────────────
  // ZONES D'INTERVENTION  ("zones")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zones-quartiers-desservis",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question: "Quels quartiers de Casablanca sont desservis ?",
    answer:
      "SAMUR Casablanca organise des soins infirmiers à domicile Casablanca, notamment à Maarif, Gauthier, Racine, Bourgogne, Anfa, Ain Diab, Oasis, Californie et Sidi Maarouf. Ces quartiers disposent d'une page dédiée sur le site. D'autres secteurs de la ville peuvent être couverts : un appel permet de le vérifier.",
  },
  {
    id: "zones-verifier-adresse",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question: "Comment savoir si mon adresse se trouve dans la zone d'intervention ?",
    answer:
      "Pour savoir si votre adresse est couverte, indiquez le quartier et la rue lors de l'appel à SAMUR Casablanca au 06 61 30 15 34. Le service confirme alors si une intervention peut être organisée à cette adresse. Les quartiers déjà présentés sur le site sont desservis ; les secteurs voisins sont étudiés au cas par cas.",
  },
  {
    id: "zones-maarif",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Le service intervient-il à Maarif ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Maarif pour des soins infirmiers à domicile. Maarif est un quartier central et dense de Casablanca, ce qui facilite l'organisation des passages. La demande se fait par téléphone, puis l'intervention est planifiée selon la situation et la disponibilité.",
  },
  {
    id: "zones-racine",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "racine-casablanca",
    status: "published",
    question: "Le service intervient-il à Racine ?",
    answer:
      "Oui, Racine fait partie des quartiers de Casablanca où SAMUR Casablanca organise des soins infirmiers à domicile. Situé entre Gauthier et Anfa, ce secteur résidentiel est desservi sur demande. Un premier appel permet de préciser le soin et de planifier le passage.",
  },
  {
    id: "zones-gauthier",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "gauthier-casablanca",
    status: "published",
    question: "Le service intervient-il à Gauthier ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Gauthier, quartier central de Casablanca, pour des soins infirmiers à domicile. Les passages sont organisés après un échange téléphonique précisant le soin, l'adresse et l'horaire souhaité, selon la disponibilité du service.",
  },
  {
    id: "zones-bourgogne",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "bourgogne-casablanca",
    status: "published",
    question: "Le service intervient-il à Bourgogne ?",
    answer:
      "Oui, Bourgogne est desservi par SAMUR Casablanca pour les soins infirmiers à domicile. Ce quartier résidentiel de Casablanca, proche de Maarif et de Gauthier, est facilement accessible pour l'organisation des passages. La demande se fait par téléphone.",
  },
  {
    id: "zones-ain-diab",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "ain-diab",
    status: "published",
    question: "Le service intervient-il à Ain Diab ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Ain Diab, le quartier côtier de Casablanca bordé par la Corniche, pour des soins infirmiers à domicile. Les résidences et villas du secteur sont desservies sur demande, après un premier échange téléphonique.",
  },
  {
    id: "zones-anfa",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "anfa",
    status: "published",
    question: "Le service intervient-il à Anfa ?",
    answer:
      "Oui, Anfa fait partie des quartiers de Casablanca couverts par SAMUR Casablanca pour les soins infirmiers à domicile. Ce secteur résidentiel de villas et de résidences, situé sur les hauteurs de la ville, est desservi sur demande téléphonique.",
  },
  {
    id: "zones-oasis",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "oasis-casablanca",
    status: "published",
    question: "Le service intervient-il à Oasis ?",
    answer:
      "Oui, SAMUR Casablanca organise des soins infirmiers à domicile Oasis, quartier résidentiel du sud de Casablanca. L'habitat pavillonnaire du secteur se prête bien aux interventions à domicile, planifiées après un premier contact téléphonique.",
  },
  {
    id: "zones-californie",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "californie-casablanca",
    status: "published",
    question: "Le service intervient-il à Californie ?",
    answer:
      "Oui, Californie est desservi par SAMUR Casablanca pour les soins infirmiers à domicile. Ce quartier du sud-ouest de Casablanca, proche de Sidi Maarouf et d'Anfa, est couvert sur demande, de même que plusieurs résidences voisines.",
  },
  {
    id: "zones-sidi-maarouf",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "sidi-maarouf",
    status: "published",
    question: "Le service intervient-il à Sidi Maarouf ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Sidi Maarouf, pôle résidentiel et d'affaires du sud de Casablanca, pour des soins infirmiers à domicile. Les résidences du quartier sont desservies sur demande, après un échange téléphonique précisant le soin et l'adresse.",
  },
  {
    id: "zones-hors-liste",
    category: "zones",
    pages: ["zones"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question:
      "Peut-on contacter le service si son quartier n'est pas encore indiqué sur le site ?",
    answer:
      "Oui. Si votre quartier de Casablanca n'apparaît pas encore sur le site, vous pouvez tout de même contacter SAMUR Casablanca au 06 61 30 15 34. Le service indiquera si une intervention peut être organisée à votre adresse. La liste des quartiers présentés évolue et ne couvre pas nécessairement tous les secteurs desservis.",
  },

  // ─────────────────────────────────────────────────────────────
  // CONTACT  ("contact")
  // ─────────────────────────────────────────────────────────────
  {
    id: "contact-comment",
    category: "contact",
    pages: ["contact"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question:
      "Comment contacter le service de soins infirmiers à domicile Casablanca ?",
    answer:
      "Le service présenté sur infirmiercasablanca.ma peut être contacté au 06 61 30 15 34 ou au 05 22 98 16 16. La disponibilité communiquée est de 24h/24 et 7j/7. Un email est également disponible à urgencesamur@gmail.com. Les informations nécessaires à l'organisation d'une intervention sont précisées lors de la prise de contact.",
  },
  {
    id: "contact-numero-intervention",
    category: "contact",
    pages: ["contact"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Quel numéro appeler pour demander une intervention ?",
    answer:
      "Pour demander une intervention de soins infirmiers à domicile Casablanca, appelez SAMUR Casablanca au 06 61 30 15 34. Le numéro fixe 05 22 98 16 16 est également disponible. L'appel permet de décrire le soin recherché et d'organiser le passage selon la situation et la disponibilité.",
  },
  {
    id: "contact-mobile",
    category: "contact",
    pages: ["contact"],
    service: null,
    zone: null,
    status: "published",
    question: "Quel est le numéro mobile du service ?",
    answer:
      "Le numéro mobile de SAMUR Casablanca est le 06 61 30 15 34. Il permet de joindre le service pour organiser des soins infirmiers à domicile Casablanca. Le même numéro est utilisé pour l'échange préalable qui précède chaque intervention.",
  },
  {
    id: "contact-fixe",
    category: "contact",
    pages: ["contact"],
    service: null,
    zone: null,
    status: "published",
    question: "Quel est le numéro fixe ?",
    answer:
      "Le numéro fixe de SAMUR Casablanca est le 05 22 98 16 16. Il constitue une alternative au numéro mobile 06 61 30 15 34 pour contacter le service de soins infirmiers à domicile Casablanca.",
  },
  {
    id: "contact-adresse",
    category: "contact",
    pages: ["contact"],
    service: null,
    zone: "casablanca",
    status: "published",
    hub: true,
    question: "Quelle est l'adresse communiquée à Casablanca ?",
    answer:
      "L'adresse communiquée par SAMUR Casablanca est le 343 Rue Mostafa El Maani, Casablanca. Il s'agit d'une adresse de contact : les soins infirmiers, eux, sont réalisés au domicile du patient. Il n'est pas nécessaire de s'y rendre pour organiser une intervention, un appel suffit.",
  },
  {
    id: "contact-email",
    category: "contact",
    pages: ["contact"],
    service: null,
    zone: null,
    status: "published",
    question: "Quel est l'email de contact ?",
    answer:
      "L'email de contact est urgencesamur@gmail.com. Il permet d'écrire à SAMUR Casablanca au sujet d'une demande de soins infirmiers à domicile Casablanca. Pour organiser rapidement une intervention, le téléphone (06 61 30 15 34 ou 05 22 98 16 16) reste le moyen le plus direct.",
  },
  {
    id: "contact-247",
    category: "horaires",
    pages: ["contact"],
    service: null,
    zone: null,
    status: "published",
    question: "Le service est-il joignable 24h/24 et 7j/7 ?",
    answer:
      "La disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel. Pour un besoin prévisible, il est utile d'appeler à l'avance afin de planifier le passage.",
  },
  {
    id: "contact-proche",
    category: "avant-intervention",
    pages: ["contact"],
    service: null,
    zone: null,
    status: "published",
    question: "Peut-on demander une intervention pour un proche ?",
    answer:
      "Oui, une intervention peut être demandée pour un proche. La personne qui appelle indique la situation, l'adresse à Casablanca et le soin concerné. Il est utile qu'un membre de l'entourage soit présent lors du premier passage, notamment si le patient a des difficultés à se déplacer ou à communiquer.",
  },
  {
    id: "contact-se-deplacer",
    category: "contact",
    pages: ["contact"],
    service: null,
    zone: null,
    status: "published",
    hub: true,
    question: "Faut-il se déplacer à l'adresse pour recevoir des soins à domicile ?",
    answer:
      "Non. Pour recevoir des soins à domicile, il n'est pas nécessaire de se déplacer au 343 Rue Mostafa El Maani : cette adresse sert au contact administratif. L'infirmier se rend au domicile du patient à Casablanca. Toute l'organisation se fait par téléphone au 06 61 30 15 34.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — MAARIF  ("zone:maarif")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-maarif-demander",
    category: "infirmier-domicile",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Comment demander un infirmier à domicile Maarif, Casablanca ?",
    answer:
      "Pour demander un infirmier à domicile Maarif, contactez SAMUR Casablanca au 06 61 30 15 34 ou au 05 22 98 16 16. Vous décrivez le soin recherché et votre adresse dans le quartier, puis le passage est organisé selon la situation et la disponibilité. Maarif étant un quartier central de Casablanca, les interventions y sont généralement simples à planifier.",
  },
  {
    id: "zone-maarif-soins",
    category: "soins-infirmiers",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Quels soins infirmiers peuvent être organisés à domicile Maarif ?",
    answer:
      "Les soins infirmiers courants peuvent être organisés à domicile Maarif, sur prescription lorsqu'elle est nécessaire. Le type de soin réalisable dépend de la situation du patient et des indications médicales. SAMUR Casablanca précise le cadre lors du premier appel, avant l'intervention dans le quartier.",
  },
  {
    id: "zone-maarif-intervient",
    category: "zones",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Le service intervient-il dans le quartier Maarif à Casablanca ?",
    answer:
      "Oui, SAMUR Casablanca intervient dans le quartier Maarif pour des soins infirmiers à domicile. Maarif fait partie des secteurs de Casablanca présentés sur le site et desservis sur demande. Les abords immédiats du quartier sont également couverts.",
  },
  {
    id: "zone-maarif-nuit",
    category: "horaires",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Peut-on demander une intervention infirmière à Maarif la nuit ?",
    answer:
      "La disponibilité annoncée par SAMUR Casablanca est de 24h/24, la nuit comprise, y compris à Maarif. Une demande nocturne est organisée selon la situation et les disponibilités au moment de l'appel. En cas d'urgence vitale, il faut contacter les services d'urgence officiels.",
  },
  {
    id: "zone-maarif-dimanche",
    category: "horaires",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Le service est-il disponible le dimanche à Maarif ?",
    answer:
      "Oui, la disponibilité annoncée est de 7j/7, dimanche inclus, pour le quartier Maarif. L'intervention est organisée comme en semaine, selon la situation et les disponibilités. Pour un soin régulier le dimanche, il est préférable de le planifier à l'avance avec SAMUR Casablanca.",
  },
  {
    id: "zone-maarif-ordonnance",
    category: "ordonnances",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Une ordonnance est-elle nécessaire pour certains soins à domicile ?",
    answer:
      "Oui, certains soins infirmiers nécessitent une prescription médicale, d'autres non, selon leur nature. Lorsqu'une ordonnance existe, elle doit être disponible lors du passage de l'infirmier à Maarif. En cas de doute, indiquez le soin recherché lors de l'appel à SAMUR Casablanca.",
  },
  {
    id: "zone-maarif-tarif",
    category: "tarifs",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Maarif ?",
    answer:
      "Le tarif d'une intervention à Maarif dépend du soin, de sa durée et du nombre de passages. Aucun montant n'est communiqué à l'avance : il est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },
  {
    id: "zone-maarif-numero",
    category: "contact",
    pages: ["zone:maarif"],
    service: null,
    zone: "maarif",
    status: "published",
    question: "Quel numéro appeler pour demander une intervention à Maarif ?",
    answer:
      "Pour une intervention à Maarif, appelez SAMUR Casablanca au 06 61 30 15 34 ou au 05 22 98 16 16. L'email urgencesamur@gmail.com est également disponible. L'appel permet de décrire le soin et de planifier le passage dans le quartier.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — RACINE  ("zone:racine-casablanca")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-racine-demander",
    category: "infirmier-domicile",
    pages: ["zone:racine-casablanca"],
    service: null,
    zone: "racine-casablanca",
    status: "published",
    question: "Comment demander un infirmier à domicile Racine ?",
    answer:
      "Pour demander un infirmier à domicile Racine, contactez SAMUR Casablanca au 06 61 30 15 34. Après un échange sur le soin recherché et votre adresse dans ce quartier résidentiel de Casablanca, le passage est organisé selon la situation et la disponibilité.",
  },
  {
    id: "zone-racine-intervient",
    category: "zones",
    pages: ["zone:racine-casablanca"],
    service: null,
    zone: "racine-casablanca",
    status: "published",
    question: "Le service intervient-il dans le quartier Racine ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Racine pour des soins infirmiers à domicile. Situé entre Gauthier et Anfa, ce quartier de Casablanca est desservi sur demande, de même que ses abords.",
  },
  {
    id: "zone-racine-suivi-regulier",
    category: "soins-infirmiers",
    pages: ["zone:racine-casablanca"],
    service: null,
    zone: "racine-casablanca",
    status: "published",
    question: "Proposez-vous un suivi infirmier régulier à Racine ?",
    answer:
      "Un suivi infirmier régulier peut être mis en place à Racine, avec des passages planifiés selon la prescription et l'évolution de la situation. La fréquence est définie avec SAMUR Casablanca lors de la prise de contact, puis ajustée si le besoin change. Ce type de suivi est fréquent pour les soins de plaies ou l'accompagnement d'une personne âgée.",
  },
  {
    id: "zone-racine-secteurs-proches",
    category: "zones",
    pages: ["zone:racine-casablanca"],
    service: null,
    zone: "racine-casablanca",
    status: "published",
    question: "Quels secteurs proches de Racine sont aussi desservis ?",
    answer:
      "Autour de Racine, SAMUR Casablanca dessert notamment Gauthier, Anfa et Maarif, ainsi que les rues intermédiaires de ce secteur central de Casablanca. Si votre adresse se situe en limite de quartier, un appel permet de confirmer que l'intervention peut être organisée.",
  },
  {
    id: "zone-racine-nuit-dimanche",
    category: "horaires",
    pages: ["zone:racine-casablanca"],
    service: null,
    zone: "racine-casablanca",
    status: "published",
    question: "Une intervention est-elle possible la nuit ou le dimanche à Racine ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, nuit et dimanche compris, pour le quartier Racine. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel. En cas d'urgence vitale, contactez les services d'urgence officiels.",
  },
  {
    id: "zone-racine-tarif",
    category: "tarifs",
    pages: ["zone:racine-casablanca"],
    service: null,
    zone: "racine-casablanca",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Racine ?",
    answer:
      "Le tarif d'une intervention à Racine dépend du type de soin, de sa durée et de la fréquence des passages. Aucun montant standard n'est diffusé à l'avance : il est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — GAUTHIER  ("zone:gauthier-casablanca")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-gauthier-demander",
    category: "infirmier-domicile",
    pages: ["zone:gauthier-casablanca"],
    service: null,
    zone: "gauthier-casablanca",
    status: "published",
    question: "Comment demander un infirmier à domicile Gauthier ?",
    answer:
      "Pour demander un infirmier à domicile Gauthier, appelez SAMUR Casablanca au 06 61 30 15 34 ou au 05 22 98 16 16. Vous précisez le soin et votre adresse dans ce quartier central de Casablanca, puis le passage est planifié selon la situation et la disponibilité.",
  },
  {
    id: "zone-gauthier-intervient",
    category: "zones",
    pages: ["zone:gauthier-casablanca"],
    service: null,
    zone: "gauthier-casablanca",
    status: "published",
    question: "Le service intervient-il dans le quartier Gauthier ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Gauthier pour des soins infirmiers à domicile. Ce quartier central de Casablanca, mêlant résidences et commerces, est desservi sur demande, tout comme les secteurs voisins de Maarif et Racine.",
  },
  {
    id: "zone-gauthier-soiree",
    category: "horaires",
    pages: ["zone:gauthier-casablanca"],
    service: null,
    zone: "gauthier-casablanca",
    status: "published",
    question: "Les interventions à Gauthier sont-elles possibles en soirée ?",
    answer:
      "Oui, des interventions en soirée peuvent être organisées à Gauthier : la disponibilité annoncée par SAMUR Casablanca est de 24h/24. Un passage en fin de journée est utile lorsque le patient ou son entourage n'est disponible qu'après le travail. Il est préférable de réserver le créneau à l'avance lors de l'appel.",
  },
  {
    id: "zone-gauthier-ordonnance",
    category: "ordonnances",
    pages: ["zone:gauthier-casablanca"],
    service: null,
    zone: "gauthier-casablanca",
    status: "published",
    question: "Faut-il une ordonnance pour un soin à domicile Gauthier ?",
    answer:
      "Cela dépend du soin : certains actes infirmiers réalisés à Gauthier nécessitent une prescription médicale, d'autres non. Lorsqu'une ordonnance existe, elle doit être présentée à l'infirmier lors du passage. Si vous ignorez si une prescription est requise, indiquez le soin souhaité lors de l'appel à SAMUR Casablanca.",
  },
  {
    id: "zone-gauthier-weekend",
    category: "horaires",
    pages: ["zone:gauthier-casablanca"],
    service: null,
    zone: "gauthier-casablanca",
    status: "published",
    question: "Le service est-il disponible le week-end à Gauthier ?",
    answer:
      "Oui, la disponibilité annoncée est de 7j/7, samedi et dimanche compris, pour le quartier Gauthier. Les demandes du week-end sont organisées selon la situation et les disponibilités. Pour un soin régulier, il est conseillé de planifier les passages à l'avance.",
  },
  {
    id: "zone-gauthier-tarif",
    category: "tarifs",
    pages: ["zone:gauthier-casablanca"],
    service: null,
    zone: "gauthier-casablanca",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Gauthier ?",
    answer:
      "Le tarif d'une intervention à Gauthier dépend du soin, de sa durée et du nombre de passages. Aucune grille n'est communiquée à l'avance : le montant est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — BOURGOGNE  ("zone:bourgogne-casablanca")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-bourgogne-demander",
    category: "infirmier-domicile",
    pages: ["zone:bourgogne-casablanca"],
    service: null,
    zone: "bourgogne-casablanca",
    status: "published",
    question: "Comment demander un infirmier à domicile Bourgogne ?",
    answer:
      "Pour demander un infirmier à domicile Bourgogne, contactez SAMUR Casablanca au 06 61 30 15 34. Après un échange sur le soin et votre adresse dans ce quartier résidentiel de Casablanca, le passage est organisé selon la situation et la disponibilité.",
  },
  {
    id: "zone-bourgogne-intervient",
    category: "zones",
    pages: ["zone:bourgogne-casablanca"],
    service: null,
    zone: "bourgogne-casablanca",
    status: "published",
    question: "Le service intervient-il dans le quartier Bourgogne ?",
    answer:
      "Oui, SAMUR Casablanca dessert Bourgogne pour les soins infirmiers à domicile. Proche de Maarif et de Gauthier, ce quartier de Casablanca est facilement accessible, ce qui simplifie l'organisation des passages.",
  },
  {
    id: "zone-bourgogne-soins",
    category: "soins-infirmiers",
    pages: ["zone:bourgogne-casablanca"],
    service: null,
    zone: "bourgogne-casablanca",
    status: "published",
    question: "Quels soins peuvent être réalisés à domicile Bourgogne ?",
    answer:
      "À Bourgogne, les soins infirmiers courants peuvent être réalisés à domicile, sur prescription lorsqu'elle est nécessaire. Le type de soin possible dépend de l'état du patient et des indications médicales. SAMUR Casablanca en précise le cadre lors du premier appel, avant l'intervention dans le quartier.",
  },
  {
    id: "zone-bourgogne-proximite",
    category: "zones",
    pages: ["zone:bourgogne-casablanca"],
    service: null,
    zone: "bourgogne-casablanca",
    status: "published",
    question: "Intervenez-vous aussi à proximité, vers Maarif ou Gauthier ?",
    answer:
      "Oui, les secteurs limitrophes de Bourgogne, notamment Maarif, Gauthier et Racine, sont également desservis par SAMUR Casablanca. Si votre adresse se trouve à la frontière entre ces quartiers de Casablanca, un appel permet de confirmer que l'intervention peut être organisée.",
  },
  {
    id: "zone-bourgogne-nuit-dimanche",
    category: "horaires",
    pages: ["zone:bourgogne-casablanca"],
    service: null,
    zone: "bourgogne-casablanca",
    status: "published",
    question: "Une intervention est-elle possible la nuit ou le dimanche à Bourgogne ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, nuit et dimanche compris, pour le quartier Bourgogne. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel.",
  },
  {
    id: "zone-bourgogne-tarif",
    category: "tarifs",
    pages: ["zone:bourgogne-casablanca"],
    service: null,
    zone: "bourgogne-casablanca",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Bourgogne ?",
    answer:
      "Le tarif d'une intervention à Bourgogne dépend du soin, de sa durée et de la fréquence des passages. Aucun montant n'est diffusé à l'avance : il est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — AIN DIAB  ("zone:ain-diab")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-aindiab-demander",
    category: "infirmier-domicile",
    pages: ["zone:ain-diab"],
    service: null,
    zone: "ain-diab",
    status: "published",
    question: "Comment demander un infirmier à domicile Ain Diab ?",
    answer:
      "Pour demander un infirmier à domicile Ain Diab, appelez SAMUR Casablanca au 06 61 30 15 34 ou au 05 22 98 16 16. Vous indiquez le soin recherché et votre adresse dans ce quartier côtier de Casablanca, puis le passage est organisé selon la situation et la disponibilité.",
  },
  {
    id: "zone-aindiab-corniche",
    category: "zones",
    pages: ["zone:ain-diab"],
    service: null,
    zone: "ain-diab",
    status: "published",
    question: "Le service intervient-il à Ain Diab, le long de la Corniche ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Ain Diab, y compris dans les résidences et villas situées le long de la Corniche. Ce quartier côtier de Casablanca est desservi sur demande, après un premier échange téléphonique précisant l'adresse et le soin.",
  },
  {
    id: "zone-aindiab-sejour-temporaire",
    category: "avant-intervention",
    pages: ["zone:ain-diab"],
    service: null,
    zone: "ain-diab",
    status: "published",
    question:
      "Proposez-vous des soins pour une personne en séjour temporaire à Ain Diab ?",
    answer:
      "Oui, une demande de soins peut être faite pour une personne en séjour temporaire à Ain Diab, par exemple à l'hôtel ou dans une location. Il suffit d'indiquer l'adresse exacte et le soin concerné lors de l'appel à SAMUR Casablanca. L'organisation dépend ensuite du besoin exprimé et de la disponibilité.",
  },
  {
    id: "zone-aindiab-nuit-dimanche",
    category: "horaires",
    pages: ["zone:ain-diab"],
    service: null,
    zone: "ain-diab",
    status: "published",
    question: "Une intervention est-elle possible la nuit ou le dimanche à Ain Diab ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, nuit et dimanche compris, pour le quartier Ain Diab. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel.",
  },
  {
    id: "zone-aindiab-ordonnance",
    category: "ordonnances",
    pages: ["zone:ain-diab"],
    service: null,
    zone: "ain-diab",
    status: "published",
    question: "Une ordonnance est-elle nécessaire pour certains soins à domicile ?",
    answer:
      "Oui, certains soins infirmiers nécessitent une prescription médicale, d'autres non, selon leur nature. Lorsqu'une ordonnance existe, elle doit être disponible lors du passage de l'infirmier à Ain Diab. En cas de doute, précisez le soin recherché lors de l'appel à SAMUR Casablanca.",
  },
  {
    id: "zone-aindiab-tarif",
    category: "tarifs",
    pages: ["zone:ain-diab"],
    service: null,
    zone: "ain-diab",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Ain Diab ?",
    answer:
      "Le tarif d'une intervention à Ain Diab dépend du soin, de sa durée et du nombre de passages. Aucun montant standard n'est communiqué à l'avance : il est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — ANFA  ("zone:anfa")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-anfa-demander",
    category: "infirmier-domicile",
    pages: ["zone:anfa"],
    service: null,
    zone: "anfa",
    status: "published",
    question: "Comment demander un infirmier à domicile Anfa ?",
    answer:
      "Pour demander un infirmier à domicile Anfa, contactez SAMUR Casablanca au 06 61 30 15 34. Après un échange sur le soin et votre adresse dans ce quartier résidentiel de Casablanca, le passage est organisé selon la situation et la disponibilité.",
  },
  {
    id: "zone-anfa-villas",
    category: "zones",
    pages: ["zone:anfa"],
    service: null,
    zone: "anfa",
    status: "published",
    question: "Intervenez-vous dans les villas et résidences d'Anfa ?",
    answer:
      "Oui, SAMUR Casablanca intervient dans les villas et les résidences d'Anfa pour des soins infirmiers à domicile. Ce secteur des hauteurs de Casablanca est desservi sur demande. Il est utile de préciser l'accès (étage, portail, interphone) lors de l'appel pour faciliter le passage.",
  },
  {
    id: "zone-anfa-residents",
    category: "avant-intervention",
    pages: ["zone:anfa"],
    service: null,
    zone: "anfa",
    status: "published",
    question: "Les soins à domicile Anfa sont-ils réservés aux résidents permanents ?",
    answer:
      "Non, les soins à domicile Anfa ne sont pas réservés aux résidents permanents. Une demande peut concerner une résidence principale comme un séjour temporaire dans le quartier. Chaque situation est étudiée individuellement lors du contact avec SAMUR Casablanca, selon le besoin et la disponibilité.",
  },
  {
    id: "zone-anfa-nuit-dimanche",
    category: "horaires",
    pages: ["zone:anfa"],
    service: null,
    zone: "anfa",
    status: "published",
    question: "Une intervention est-elle possible la nuit ou le dimanche à Anfa ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, nuit et dimanche compris, pour le quartier Anfa. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel.",
  },
  {
    id: "zone-anfa-ordonnance",
    category: "ordonnances",
    pages: ["zone:anfa"],
    service: null,
    zone: "anfa",
    status: "published",
    question: "Une ordonnance est-elle nécessaire pour certains soins à domicile ?",
    answer:
      "Oui, certains soins infirmiers nécessitent une prescription médicale, d'autres non, selon leur nature. Lorsqu'une ordonnance existe, elle doit être présentée à l'infirmier lors du passage à Anfa. En cas de doute, indiquez le soin souhaité lors de l'appel à SAMUR Casablanca.",
  },
  {
    id: "zone-anfa-tarif",
    category: "tarifs",
    pages: ["zone:anfa"],
    service: null,
    zone: "anfa",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Anfa ?",
    answer:
      "Le tarif d'une intervention à Anfa dépend du soin, de sa durée et du nombre de passages. Aucune grille n'est diffusée à l'avance : le montant est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — OASIS  ("zone:oasis-casablanca")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-oasis-demander",
    category: "infirmier-domicile",
    pages: ["zone:oasis-casablanca"],
    service: null,
    zone: "oasis-casablanca",
    status: "published",
    question: "Comment demander un infirmier à domicile Oasis ?",
    answer:
      "Pour demander un infirmier à domicile Oasis, appelez SAMUR Casablanca au 06 61 30 15 34. Vous précisez le soin recherché et votre adresse dans ce quartier du sud de Casablanca, puis le passage est organisé selon la situation et la disponibilité.",
  },
  {
    id: "zone-oasis-intervient",
    category: "zones",
    pages: ["zone:oasis-casablanca"],
    service: null,
    zone: "oasis-casablanca",
    status: "published",
    question: "Le service intervient-il dans le quartier Oasis ?",
    answer:
      "Oui, SAMUR Casablanca dessert Oasis pour les soins infirmiers à domicile. Ce quartier résidentiel du sud de Casablanca, à l'habitat majoritairement pavillonnaire, est couvert sur demande, tout comme les secteurs voisins de Sidi Maarouf.",
  },
  {
    id: "zone-oasis-personne-agee",
    category: "personnes-agees",
    pages: ["zone:oasis-casablanca"],
    service: null,
    zone: "oasis-casablanca",
    status: "published",
    question: "Peut-on organiser des soins à domicile pour une personne âgée à Oasis ?",
    answer:
      "Oui, des soins infirmiers à domicile peuvent être organisés pour une personne âgée à Oasis, à sa demande ou à celle d'un proche. Les passages ont lieu à son domicile habituel dans le quartier. Lors de l'appel à SAMUR Casablanca, précisez le degré d'autonomie de la personne et les soins prescrits.",
  },
  {
    id: "zone-oasis-plusieurs-passages",
    category: "avant-intervention",
    pages: ["zone:oasis-casablanca"],
    service: null,
    zone: "oasis-casablanca",
    status: "published",
    question: "Comment planifier plusieurs passages infirmiers à Oasis ?",
    answer:
      "Pour planifier plusieurs passages infirmiers à Oasis, indiquez lors de l'appel la fréquence souhaitée et la période concernée. Un calendrier est établi avec SAMUR Casablanca selon la prescription, puis ajusté si le besoin évolue. Ce suivi est courant pour les soins de plaies ou l'accompagnement d'une personne âgée.",
  },
  {
    id: "zone-oasis-nuit-dimanche",
    category: "horaires",
    pages: ["zone:oasis-casablanca"],
    service: null,
    zone: "oasis-casablanca",
    status: "published",
    question: "Une intervention est-elle possible la nuit ou le dimanche à Oasis ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, nuit et dimanche compris, pour le quartier Oasis. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel.",
  },
  {
    id: "zone-oasis-tarif",
    category: "tarifs",
    pages: ["zone:oasis-casablanca"],
    service: null,
    zone: "oasis-casablanca",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Oasis ?",
    answer:
      "Le tarif d'une intervention à Oasis dépend du soin, de sa durée et du nombre de passages. Aucun montant n'est communiqué à l'avance : il est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — CALIFORNIE  ("zone:californie-casablanca")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-californie-demander",
    category: "infirmier-domicile",
    pages: ["zone:californie-casablanca"],
    service: null,
    zone: "californie-casablanca",
    status: "published",
    question: "Comment demander un infirmier à domicile Californie ?",
    answer:
      "Pour demander un infirmier à domicile Californie, contactez SAMUR Casablanca au 06 61 30 15 34 ou au 05 22 98 16 16. Après un échange sur le soin et votre adresse dans ce quartier du sud-ouest de Casablanca, le passage est organisé selon la situation et la disponibilité.",
  },
  {
    id: "zone-californie-intervient",
    category: "zones",
    pages: ["zone:californie-casablanca"],
    service: null,
    zone: "californie-casablanca",
    status: "published",
    question: "Le service intervient-il dans le quartier Californie ?",
    answer:
      "Oui, SAMUR Casablanca intervient à Californie pour des soins infirmiers à domicile. Ce quartier résidentiel et d'affaires du sud-ouest de Casablanca est desservi sur demande, de même que les secteurs proches de Sidi Maarouf et d'Anfa.",
  },
  {
    id: "zone-californie-residences-proches",
    category: "zones",
    pages: ["zone:californie-casablanca"],
    service: null,
    zone: "californie-casablanca",
    status: "published",
    question: "Intervenez-vous dans les résidences proches, vers Sidi Maarouf ?",
    answer:
      "Oui, les résidences situées entre Californie et Sidi Maarouf sont desservies par SAMUR Casablanca. Si votre adresse se trouve en limite de quartier, dans ce secteur en développement de Casablanca, un appel permet de confirmer que l'intervention peut être organisée.",
  },
  {
    id: "zone-californie-soins",
    category: "soins-infirmiers",
    pages: ["zone:californie-casablanca"],
    service: null,
    zone: "californie-casablanca",
    status: "published",
    question: "Quels soins sont disponibles à domicile Californie ?",
    answer:
      "À Californie, les soins infirmiers courants peuvent être réalisés à domicile, sur prescription lorsqu'elle est nécessaire. Le type de soin possible dépend de l'état du patient et des indications médicales. SAMUR Casablanca en précise le cadre lors du premier appel.",
  },
  {
    id: "zone-californie-nuit-dimanche",
    category: "horaires",
    pages: ["zone:californie-casablanca"],
    service: null,
    zone: "californie-casablanca",
    status: "published",
    question: "Une intervention est-elle possible la nuit ou le dimanche à Californie ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, nuit et dimanche compris, pour le quartier Californie. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel.",
  },
  {
    id: "zone-californie-tarif",
    category: "tarifs",
    pages: ["zone:californie-casablanca"],
    service: null,
    zone: "californie-casablanca",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Californie ?",
    answer:
      "Le tarif d'une intervention à Californie dépend du soin, de sa durée et du nombre de passages. Aucune grille n'est diffusée à l'avance : le montant est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // QUARTIER — SIDI MAAROUF  ("zone:sidi-maarouf")
  // ─────────────────────────────────────────────────────────────
  {
    id: "zone-sidimaarouf-demander",
    category: "infirmier-domicile",
    pages: ["zone:sidi-maarouf"],
    service: null,
    zone: "sidi-maarouf",
    status: "published",
    question: "Comment demander un infirmier à domicile Sidi Maarouf ?",
    answer:
      "Pour demander un infirmier à domicile Sidi Maarouf, appelez SAMUR Casablanca au 06 61 30 15 34. Vous indiquez le soin recherché et votre adresse dans ce pôle du sud de Casablanca, puis le passage est organisé selon la situation et la disponibilité.",
  },
  {
    id: "zone-sidimaarouf-residences",
    category: "zones",
    pages: ["zone:sidi-maarouf"],
    service: null,
    zone: "sidi-maarouf",
    status: "published",
    question: "Intervenez-vous dans les résidences récentes de Sidi Maarouf ?",
    answer:
      "Oui, SAMUR Casablanca intervient dans les résidences récentes de Sidi Maarouf pour des soins infirmiers à domicile. Ce secteur du sud de Casablanca, développé autour de résidences et de bureaux, est desservi sur demande. Préciser l'accès (bâtiment, étage, interphone) lors de l'appel facilite le passage.",
  },
  {
    id: "zone-sidimaarouf-voisins",
    category: "zones",
    pages: ["zone:sidi-maarouf"],
    service: null,
    zone: "sidi-maarouf",
    status: "published",
    question: "Quels secteurs voisins de Sidi Maarouf sont desservis ?",
    answer:
      "Autour de Sidi Maarouf, SAMUR Casablanca dessert notamment Californie et Oasis, ainsi que les résidences intermédiaires de ce secteur sud de Casablanca. Si votre adresse se situe en limite de quartier, un appel permet de confirmer que l'intervention peut être organisée.",
  },
  {
    id: "zone-sidimaarouf-nuit-dimanche",
    category: "horaires",
    pages: ["zone:sidi-maarouf"],
    service: null,
    zone: "sidi-maarouf",
    status: "published",
    question:
      "Une intervention est-elle possible la nuit ou le dimanche à Sidi Maarouf ?",
    answer:
      "Oui, la disponibilité annoncée par SAMUR Casablanca est de 24h/24 et 7j/7, nuit et dimanche compris, pour le quartier Sidi Maarouf. Chaque demande est organisée selon la situation et les disponibilités au moment de l'appel.",
  },
  {
    id: "zone-sidimaarouf-ordonnance",
    category: "ordonnances",
    pages: ["zone:sidi-maarouf"],
    service: null,
    zone: "sidi-maarouf",
    status: "published",
    question: "Une ordonnance est-elle nécessaire pour certains soins à domicile ?",
    answer:
      "Oui, certains soins infirmiers nécessitent une prescription médicale, d'autres non, selon leur nature. Lorsqu'une ordonnance existe, elle doit être disponible lors du passage de l'infirmier à Sidi Maarouf. En cas de doute, indiquez le soin recherché lors de l'appel à SAMUR Casablanca.",
  },
  {
    id: "zone-sidimaarouf-tarif",
    category: "tarifs",
    pages: ["zone:sidi-maarouf"],
    service: null,
    zone: "sidi-maarouf",
    status: "published",
    question: "Comment connaître le tarif d'une intervention à Sidi Maarouf ?",
    answer:
      "Le tarif d'une intervention à Sidi Maarouf dépend du soin, de sa durée et du nombre de passages. Aucun montant n'est communiqué à l'avance : il est précisé lors de l'échange téléphonique avec SAMUR Casablanca, une fois le besoin connu.",
  },

  // ─────────────────────────────────────────────────────────────
  // PAGES DE SERVICE — NON CONFIRMÉES (jamais rendues : status "a-confirmer")
  // Les listes complètes des sections §7–§12 de la mission seront ajoutées
  // et passées à "published" quand le client aura confirmé chaque prestation
  // ET qu'une page dédiée aura été créée.
  // ─────────────────────────────────────────────────────────────
  {
    id: "svc-pansement-demander",
    category: "pansements",
    pages: ["service:pansement"],
    service: "pansement",
    zone: "casablanca",
    status: "a-confirmer",
    question: "Comment demander un pansement à domicile Casablanca ?",
    answer:
      "Un pansement à domicile est réalisé sur prescription médicale lorsqu'elle est requise. Les modalités pratiques seront précisées une fois cette prestation confirmée par SAMUR Casablanca.",
  },
  {
    id: "svc-pansement-ordonnance",
    category: "pansements",
    pages: ["service:pansement"],
    service: "pansement",
    zone: null,
    status: "a-confirmer",
    question: "Une ordonnance est-elle nécessaire pour un pansement à domicile ?",
    answer:
      "La réfection d'un pansement à domicile s'inscrit généralement dans le cadre d'une prescription médicale. Le détail sera précisé après confirmation du service.",
  },
  {
    id: "svc-injection-demander",
    category: "injections",
    pages: ["service:injection"],
    service: "injection",
    zone: "casablanca",
    status: "a-confirmer",
    question: "Comment demander une injection à domicile Casablanca ?",
    answer:
      "Une injection à domicile est réalisée sur prescription médicale. Les modalités seront précisées une fois cette prestation confirmée par SAMUR Casablanca.",
  },
  {
    id: "svc-injection-prescription",
    category: "injections",
    pages: ["service:injection"],
    service: "injection",
    zone: null,
    status: "a-confirmer",
    question: "Une prescription est-elle nécessaire pour une injection à domicile ?",
    answer:
      "Oui, une injection à domicile nécessite une prescription médicale indiquant le produit, la dose et la fréquence. Cette rubrique sera complétée après confirmation du service.",
  },
  {
    id: "svc-perfusion-organiser",
    category: "perfusions",
    pages: ["service:perfusion"],
    service: "perfusion",
    zone: "casablanca",
    status: "a-confirmer",
    question: "Peut-on organiser une perfusion à domicile Casablanca ?",
    answer:
      "L'organisation d'une perfusion à domicile dépend d'une prescription médicale et de l'évaluation du caractère adapté au domicile. Cette rubrique sera précisée après confirmation de la prestation.",
  },
  {
    id: "svc-perfusion-prescription",
    category: "perfusions",
    pages: ["service:perfusion"],
    service: "perfusion",
    zone: null,
    status: "a-confirmer",
    question: "Une prescription médicale est-elle nécessaire pour une perfusion ?",
    answer:
      "Oui, une perfusion à domicile est réalisée uniquement sur prescription médicale. Le contenu détaillé sera ajouté après confirmation du service.",
  },
  {
    id: "svc-prise-sang-demander",
    category: "prises-de-sang",
    pages: ["service:prise-de-sang"],
    service: "prise-de-sang",
    zone: "casablanca",
    status: "a-confirmer",
    question: "Comment demander une prise de sang à domicile Casablanca ?",
    answer:
      "Une prise de sang à domicile est réalisée sur ordonnance. Les modalités pratiques seront précisées après confirmation de cette prestation par SAMUR Casablanca.",
  },
  {
    id: "svc-prise-sang-jeun",
    category: "prises-de-sang",
    pages: ["service:prise-de-sang"],
    service: "prise-de-sang",
    zone: null,
    status: "a-confirmer",
    question: "Faut-il être à jeun avant une prise de sang à domicile ?",
    answer:
      "Certaines analyses nécessitent d'être à jeun, d'autres non ; l'ordonnance ou le laboratoire l'indique. Cette rubrique sera complétée après confirmation du service.",
  },
];

/** FAQ publiées pour une page donnée (dans l'ordre de déclaration). */
export function getFaqsForPage(page: string): FaqItem[] {
  return faqs
    .filter((f) => f.status === "published" && f.pages.includes(page))
    .map((f) => ({ question: f.question, answer: f.answer }));
}

/** Groupes de catégories pour le hub /faq (catégories sans FAQ publiée omises). */
export function getHubFaqGroups(): {
  category: FaqCategory;
  label: string;
  items: FaqItem[];
}[] {
  return FAQ_HUB_ORDER.map((category) => ({
    category,
    label: FAQ_CATEGORY_LABELS[category],
    items: faqs
      .filter((f) => f.status === "published" && f.hub && f.category === category)
      .map((f) => ({ question: f.question, answer: f.answer })),
  })).filter((group) => group.items.length > 0);
}

/** Toutes les FAQ publiées visibles sur le hub (pour le JSON-LD FAQPage). */
export function getHubFaqItems(): FaqItem[] {
  return getHubFaqGroups().flatMap((group) => group.items);
}
