import { notFound } from "next/navigation";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { ZoneCard } from "@/components/sections/ZoneCard";
import { ServiceCard } from "@/components/sections/ServiceCard";
import { FAQSection } from "@/components/sections/FAQSection";
import { LocalInfo } from "@/components/sections/LocalInfo";
import { ContactCard } from "@/components/sections/ContactCard";
import { CTASection } from "@/components/sections/CTASection";
import { PhoneButton } from "@/components/ui/PhoneButton";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { zones, getZoneBySlug } from "@/data/zones";
import { services } from "@/data/services";
import { getFaqsForPage } from "@/data/faqs";
import { site } from "@/data/site";

type PageParams = { slug: string };

export function generateStaticParams() {
  return zones.map((zone) => ({ slug: zone.slug }));
}

export async function generateMetadata({ params }: { params: Promise<PageParams> }) {
  const { slug } = await params;
  const zone = getZoneBySlug(slug);
  if (!zone) return {};

  return buildMetadata({
    title: zone.title,
    description: zone.metaDescription,
    path: `/infirmier-a-domicile-${zone.slug}`,
  });
}

export default async function ZonePage({ params }: { params: Promise<PageParams> }) {
  const { slug } = await params;
  const zone = getZoneBySlug(slug);

  if (!zone) {
    notFound();
  }

  const path = `/infirmier-a-domicile-${zone.slug}`;
  const faqItems = getFaqsForPage(`zone:${zone.slug}`);
  const neighboringZones = zone.neighboringSlugs
    .map((s) => getZoneBySlug(s))
    .filter((z): z is NonNullable<typeof z> => Boolean(z));

  return (
    <>
      <JsonLd
        data={webPageSchema({
          title: zone.title,
          description: zone.metaDescription,
          path,
        })}
      />

      <Breadcrumbs
        items={[
          { name: "Accueil", path: "/" },
          { name: "Zones d'intervention", path: "/zones-intervention-casablanca" },
          { name: zone.name, path },
        ]}
      />

      <Container className="py-12">
        <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">{zone.title}</h1>
        <p className="mt-4 max-w-2xl text-lg text-navy-700">{zone.intro}</p>
        <div className="mt-6">
          <PhoneButton href={site.phones.mobile.href} label={`Appeler ${site.phones.mobile.display}`} />
        </div>
      </Container>

      <section className="bg-surface-gray py-12">
        <Container>
          <h2 className="text-2xl font-bold text-navy-950">Le quartier {zone.name}</h2>
          <p className="mt-4 max-w-3xl text-navy-700">{zone.localContext}</p>
        </Container>
      </section>

      <Container className="py-12">
        <h2 className="text-2xl font-bold text-navy-950">
          Soins disponibles à domicile {zone.name}
        </h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <ServiceCard key={service.slug} service={service} />
          ))}
        </div>
      </Container>

      <section className="bg-surface-gray py-12">
        <Container>
          <h2 className="text-2xl font-bold text-navy-950">Informations pratiques</h2>
          <p className="mt-4 max-w-3xl text-navy-700">{zone.practicalInfo}</p>
        </Container>
      </section>

      {neighboringZones.length > 0 && (
        <Container className="py-12">
          <h2 className="text-2xl font-bold text-navy-950">Secteurs voisins</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {neighboringZones.map((neighbor) => (
              <ZoneCard key={neighbor.slug} zone={neighbor} />
            ))}
          </div>
        </Container>
      )}

      <section className="bg-surface-gray py-12">
        <Container className="grid gap-8 lg:grid-cols-2">
          <LocalInfo zoneName={zone.name} />
          <ContactCard />
        </Container>
      </section>

      <FAQSection
        title={`Questions fréquentes — infirmier à domicile ${zone.name}`}
        intro={`Demande d'intervention, disponibilité et informations pratiques pour le quartier ${zone.name}, à Casablanca.`}
        items={faqItems}
        moreHref="/faq"
      />

      <CTASection />
    </>
  );
}
