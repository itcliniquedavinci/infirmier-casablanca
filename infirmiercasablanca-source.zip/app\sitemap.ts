import type { MetadataRoute } from "next";
import { site } from "@/data/site";
import { zones } from "@/data/zones";

export const dynamic = "force-static";

const staticPaths = [
  "/",
  "/infirmier-a-domicile-casablanca",
  "/soins-infirmiers",
  "/zones-intervention-casablanca",
  "/faq",
  "/a-propos",
  "/contact",
  "/mentions-legales",
  "/politique-confidentialite",
];

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  const staticEntries: MetadataRoute.Sitemap = staticPaths.map((path) => ({
    url: `${site.url}${path}`,
    lastModified: now,
    changeFrequency: path === "/" ? "weekly" : "monthly",
    priority: path === "/" ? 1 : path === "/infirmier-a-domicile-casablanca" ? 0.9 : 0.6,
  }));

  const zoneEntries: MetadataRoute.Sitemap = zones.map((zone) => ({
    url: `${site.url}/infirmier-a-domicile-${zone.slug}`,
    lastModified: now,
    changeFrequency: "monthly",
    priority: 0.7,
  }));

  return [...staticEntries, ...zoneEntries];
}
