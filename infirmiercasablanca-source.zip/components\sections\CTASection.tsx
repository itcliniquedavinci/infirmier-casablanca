import { site } from "@/data/site";
import { Container } from "@/components/ui/Container";
import { PhoneButton } from "@/components/ui/PhoneButton";

type CTASectionProps = {
  title?: string;
  description?: string;
};

export function CTASection({
  title = "Besoin d'organiser une intervention à domicile ?",
  description = "Contactez SAMUR Casablanca pour échanger sur votre besoin. Nous organisons l'intervention selon votre situation.",
}: CTASectionProps) {
  return (
    <section className="bg-navy-950 py-14">
      <Container className="flex flex-col items-center gap-6 text-center">
        <h2 className="max-w-2xl text-2xl font-bold text-white sm:text-3xl">{title}</h2>
        <p className="max-w-xl text-navy-100/80">{description}</p>
        <div className="flex flex-col gap-3 sm:flex-row">
          <PhoneButton href={site.phones.mobile.href} label={`Appeler ${site.phones.mobile.display}`} />
          <PhoneButton
            href={site.phones.landline.href}
            label={site.phones.landline.display}
            variant="secondary"
          />
        </div>
      </Container>
    </section>
  );
}
