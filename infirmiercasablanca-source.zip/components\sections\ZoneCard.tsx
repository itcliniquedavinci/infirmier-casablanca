import Link from "next/link";
import type { Zone } from "@/data/zones";

export function ZoneCard({ zone }: { zone: Zone }) {
  return (
    <Link
      href={`/infirmier-a-domicile-${zone.slug}`}
      className="group flex items-center justify-between rounded-xl border border-surface-gray-dark bg-white px-5 py-4 transition-colors hover:border-brand-green-500 hover:bg-brand-green-100"
    >
      <span className="font-medium text-navy-900">{zone.name}</span>
      <span aria-hidden="true" className="text-navy-700 transition-transform group-hover:translate-x-1">
        →
      </span>
    </Link>
  );
}
