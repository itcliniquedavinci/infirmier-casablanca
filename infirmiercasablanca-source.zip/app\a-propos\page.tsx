import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { CTASection } from "@/components/sections/CTASection";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { site } from "@/data/site";

const path = "/a-propos";
const title = "À propos de SAMUR Casablanca";
const description =
  "SAMUR Casablanca est un service privé de soins infirmiers à domicile Casablanca, distinct de tout service public d'urgence.";

export const metadata = buildMetadata({ title, description, path });

export default function AProposPage() {
  return (
    <>
      <JsonLd data={webPageSchema({ title, description, path })} />
      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: "À propos", path }]} />

      <Container className="max-w-3xl py-12">
        <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">{title}</h1>

        <div className="mt-8 space-y-6 text-navy-700">
          <p>
            SAMUR Casablanca propose des soins infirmiers à domicile Casablanca. Le service
            permet d&apos;organiser une intervention infirmière directement chez le patient, selon
            le besoin exprimé et la disponibilité au moment de la demande.
          </p>

          <div className="rounded-2xl border border-navy-700/20 bg-surface-gray p-6">
            <p className="font-semibold text-navy-950">Précision importante</p>
            <p className="mt-2">{site.legalDisclaimerName}</p>
            <p className="mt-2">
              En cas d&apos;urgence vitale, contactez immédiatement les services d&apos;urgence
              officiels. SAMUR Casablanca intervient uniquement dans le cadre de soins infirmiers
              à domicile, organisés à l&apos;avance ou sur demande, en dehors de toute prise en
              charge d&apos;urgence médicale vitale.
            </p>
          </div>

          <p>
            Le service intervient à Casablanca et dans les quartiers présentés sur la page{" "}
            <a href="/zones-intervention-casablanca" className="font-medium text-brand-green-600 hover:underline">
              Zones d&apos;intervention
            </a>
            . Chaque demande fait l&apos;objet d&apos;un échange téléphonique préalable afin
            d&apos;organiser l&apos;intervention dans les meilleures conditions.
          </p>

          <p>
            Pour toute question, vous pouvez nous contacter au {site.phones.mobile.display} ou au{" "}
            {site.phones.landline.display}, par email à {site.email}, ou vous rendre à l&apos;adresse
            suivante : {site.address.full}.
          </p>
        </div>
      </Container>

      <CTASection />
    </>
  );
}
