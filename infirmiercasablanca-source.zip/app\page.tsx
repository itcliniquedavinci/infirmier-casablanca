import Link from "next/link";
import { Hero } from "@/components/sections/Hero";
import { ServiceCard } from "@/components/sections/ServiceCard";
import { ZoneCard } from "@/components/sections/ZoneCard";
import { FAQSection } from "@/components/sections/FAQSection";
import { ContactCard } from "@/components/sections/ContactCard";
import { CTASection } from "@/components/sections/CTASection";
import { Container } from "@/components/ui/Container";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { services } from "@/data/services";
import { zones } from "@/data/zones";
import { getFaqsForPage } from "@/data/faqs";
import { site } from "@/data/site";

export const metadata = {
  ...buildMetadata({
    title: `${site.brandName} — Soins infirmiers à domicile Casablanca`,
    description:
      "SAMUR Casablanca organise des soins infirmiers à domicile Casablanca. Contactez-nous pour organiser une intervention, 24h/24 et 7j/7.",
    path: "/",
  }),
  // SEO <title> de la page d'accueil uniquement. `absolute` court-circuite le
  // template `%s — SAMUR Casablanca` du layout racine ; le reste des métadonnées
  // (og:title, description, canonical…) n'est pas modifié.
  title: { absolute: "Infirmier à domicile Casablanca | Soins infirmiers" },
};

const steps = [
  {
    title: "Contacter le service",
    description: "Vous nous appelez au 06 61 30 15 34 ou au 05 22 98 16 16.",
  },
  {
    title: "Expliquer le besoin",
    description: "Nous échangeons sur la situation et le type de soin recherché.",
  },
  {
    title: "Organisation selon situation et disponibilité",
    description: "L'intervention est planifiée en fonction du besoin et des disponibilités.",
  },
  {
    title: "Intervention dans le cadre approprié",
    description: "Le soin est réalisé à domicile, dans le cadre convenu.",
  },
];

export default function HomePage() {
  return (
    <>
      <JsonLd
        data={webPageSchema({
          title: `${site.brandName} — Soins infirmiers à domicile Casablanca`,
          description: site.description,
          path: "/",
        })}
      />

      <Hero
        eyebrow={site.brandName}
        title="Soins infirmiers à domicile Casablanca"
        description="SAMUR Casablanca organise des interventions de soins infirmiers à domicile Casablanca, selon votre besoin et la disponibilité du service."
        secondaryCta={{ href: "/soins-infirmiers", label: "Découvrir les soins" }}
      />

      <Container className="py-14">
        <h2 className="text-2xl font-bold text-navy-950">Nos soins infirmiers à domicile</h2>
        <p className="mt-2 max-w-2xl text-navy-700">
          Un aperçu des catégories de soins proposées à domicile Casablanca.
        </p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <ServiceCard key={service.slug} service={service} />
          ))}
        </div>
        <Link
          href="/soins-infirmiers"
          className="mt-6 inline-block text-sm font-semibold text-brand-green-600 hover:underline"
        >
          Voir le détail des soins →
        </Link>
      </Container>

      <section className="bg-surface-gray py-14">
        <Container>
          <h2 className="text-2xl font-bold text-navy-950">Comment ça fonctionne ?</h2>
          <ol className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((step, index) => (
              <li key={step.title} className="rounded-2xl bg-white p-6 shadow-sm">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-navy-900 text-sm font-bold text-white">
                  {index + 1}
                </span>
                <p className="mt-4 font-semibold text-navy-950">{step.title}</p>
                <p className="mt-2 text-sm text-navy-700">{step.description}</p>
              </li>
            ))}
          </ol>
        </Container>
      </section>

      <Container className="py-14">
        <h2 className="text-2xl font-bold text-navy-950">Zones desservies à Casablanca</h2>
        <p className="mt-2 max-w-2xl text-navy-700">
          SAMUR Casablanca intervient à Casablanca, notamment dans les quartiers suivants.
        </p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {zones.map((zone) => (
            <ZoneCard key={zone.slug} zone={zone} />
          ))}
        </div>
        <Link
          href="/zones-intervention-casablanca"
          className="mt-6 inline-block text-sm font-semibold text-brand-green-600 hover:underline"
        >
          Voir toutes les zones d&apos;intervention →
        </Link>
      </Container>

      <FAQSection
        className="bg-surface-gray py-14"
        title="Questions fréquentes sur les soins infirmiers à domicile"
        intro="Les réponses aux questions les plus courantes avant d'organiser une intervention à domicile Casablanca."
        items={getFaqsForPage("home")}
        moreHref="/faq"
      />

      <Container className="py-14">
        <h2 className="text-2xl font-bold text-navy-950">Contact</h2>
        <div className="mt-8 max-w-md">
          <ContactCard />
        </div>
      </Container>

      <CTASection />
    </>
  );
}
