import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { ZoneCard } from "@/components/sections/ZoneCard";
import { CTASection } from "@/components/sections/CTASection";
import { FAQSection } from "@/components/sections/FAQSection";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { zones } from "@/data/zones";
import { getFaqsForPage } from "@/data/faqs";

const path = "/zones-intervention-casablanca";
const title = "Zones d'intervention à Casablanca";
const description =
  "Découvrez les quartiers de Casablanca desservis par SAMUR Casablanca pour les soins infirmiers à domicile.";

export const metadata = buildMetadata({ title, description, path });

export default function ZonesInterventionPage() {
  return (
    <>
      <JsonLd data={webPageSchema({ title, description, path })} />
      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: title, path }]} />

      <Container className="py-12">
        <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">{title}</h1>
        <p className="mt-4 max-w-2xl text-navy-700">
          SAMUR Casablanca organise des interventions de soins infirmiers à domicile Casablanca.
          Voici les quartiers actuellement desservis.
        </p>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {zones.map((zone) => (
            <ZoneCard key={zone.slug} zone={zone} />
          ))}
        </div>
      </Container>

      <FAQSection
        className="bg-surface-gray py-12"
        title="Questions fréquentes sur les zones d'intervention à Casablanca"
        intro="Quartiers desservis, vérification d'une adresse et secteurs voisins."
        items={getFaqsForPage("zones")}
      />

      <CTASection />
    </>
  );
}
