export type Zone = {
  slug: string;
  name: string;
  title: string;
  metaDescription: string;
  intro: string;
  localContext: string;
  neighboringSlugs: string[];
  practicalInfo: string;
};

export const zones: Zone[] = [
  {
    slug: "maarif",
    name: "Maarif",
    title: "Infirmier à domicile Maarif (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Maarif, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Maarif est l'un des quartiers les plus denses et les plus centraux de Casablanca, mêlant immeubles résidentiels, commerces et bureaux. SAMUR Casablanca y organise des interventions de soins infirmiers à domicile, à la demande des patients ou de leurs proches.",
    localContext:
      "Quartier animé du centre-ville, Maarif concentre une population résidentielle importante ainsi que de nombreux commerces de proximité. Cette densité facilite l'organisation d'interventions à domicile dans le quartier et ses abords immédiats.",
    neighboringSlugs: ["bourgogne-casablanca", "gauthier-casablanca", "racine-casablanca"],
    practicalInfo:
      "Les interventions à Maarif sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "ain-diab",
    name: "Ain Diab",
    title: "Infirmier à domicile Ain Diab (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Ain Diab, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Ain Diab est le quartier côtier de Casablanca, bordé par la Corniche. SAMUR Casablanca y propose des soins infirmiers à domicile pour les résidents de ce secteur résidentiel et hôtelier.",
    localContext:
      "Ain Diab se distingue par sa proximité avec le littoral et une population résidentielle répartie entre immeubles et villas. Le secteur est également fréquenté pour ses établissements hôteliers et de loisirs en bord de mer.",
    neighboringSlugs: ["anfa", "californie-casablanca"],
    practicalInfo:
      "Les interventions à Ain Diab sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "bourgogne-casablanca",
    name: "Bourgogne",
    title: "Infirmier à domicile Bourgogne (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Bourgogne, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Bourgogne est un quartier résidentiel central de Casablanca, situé à proximité de Maarif et de Gauthier. SAMUR Casablanca y organise des interventions de soins infirmiers à domicile.",
    localContext:
      "Quartier majoritairement résidentiel, Bourgogne se caractérise par ses immeubles d'habitation et sa proximité immédiate avec plusieurs axes centraux de Casablanca, ce qui facilite l'accès pour les interventions à domicile.",
    neighboringSlugs: ["maarif", "gauthier-casablanca", "racine-casablanca"],
    practicalInfo:
      "Les interventions à Bourgogne sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "gauthier-casablanca",
    name: "Gauthier",
    title: "Infirmier à domicile Gauthier (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Gauthier, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Gauthier est un quartier central de Casablanca, connu pour son mélange de résidences et de commerces de proximité. SAMUR Casablanca y organise des interventions de soins infirmiers à domicile.",
    localContext:
      "Situé au cœur de Casablanca, Gauthier est un quartier résidentiel dense entouré de commerces et de services de proximité, ce qui en fait un secteur facilement accessible pour l'organisation d'interventions à domicile.",
    neighboringSlugs: ["maarif", "racine-casablanca", "bourgogne-casablanca"],
    practicalInfo:
      "Les interventions à Gauthier sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "racine-casablanca",
    name: "Racine",
    title: "Infirmier à domicile Racine (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Racine, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Racine est un quartier résidentiel prisé de Casablanca, situé entre Gauthier et Anfa. SAMUR Casablanca y propose des soins infirmiers à domicile.",
    localContext:
      "Racine se distingue par son cadre résidentiel calme, ses avenues arborées et sa proximité avec plusieurs quartiers centraux de Casablanca, un environnement propice à l'organisation de soins à domicile.",
    neighboringSlugs: ["gauthier-casablanca", "anfa", "maarif"],
    practicalInfo:
      "Les interventions à Racine sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "anfa",
    name: "Anfa",
    title: "Infirmier à domicile Anfa (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Anfa, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Anfa est un quartier résidentiel huppé de Casablanca, situé sur les hauteurs de la ville entre Racine et la Corniche. SAMUR Casablanca y organise des interventions de soins infirmiers à domicile.",
    localContext:
      "Anfa se caractérise par ses villas et résidences, son calme et sa position en hauteur offrant une vue sur la ville et l'océan. C'est un secteur résidentiel où les interventions à domicile sont organisées au cas par cas.",
    neighboringSlugs: ["racine-casablanca", "ain-diab", "californie-casablanca"],
    practicalInfo:
      "Les interventions à Anfa sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "oasis-casablanca",
    name: "Oasis",
    title: "Infirmier à domicile Oasis (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Oasis, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Oasis est un quartier résidentiel du sud de Casablanca, apprécié pour son cadre pavillonnaire. SAMUR Casablanca y propose des soins infirmiers à domicile.",
    localContext:
      "Oasis se compose principalement de villas et de résidences familiales, dans un environnement plus aéré que le centre-ville. Ce type d'habitat facilite l'organisation d'interventions à domicile dans de bonnes conditions.",
    neighboringSlugs: ["sidi-maarouf", "maarif"],
    practicalInfo:
      "Les interventions à Oasis sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "californie-casablanca",
    name: "Californie",
    title: "Infirmier à domicile Californie (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Californie, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Californie est un quartier résidentiel et d'affaires du sud-ouest de Casablanca, à proximité de Sidi Maarouf. SAMUR Casablanca y organise des interventions de soins infirmiers à domicile.",
    localContext:
      "Le quartier Californie mêle résidences et zones d'activité, dans un secteur en développement de Casablanca. Sa proximité avec Sidi Maarouf et Anfa en fait un point de passage pour l'organisation d'interventions à domicile dans le sud-ouest de la ville.",
    neighboringSlugs: ["sidi-maarouf", "anfa", "ain-diab"],
    practicalInfo:
      "Les interventions à Californie sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
  {
    slug: "sidi-maarouf",
    name: "Sidi Maarouf",
    title: "Infirmier à domicile Sidi Maarouf (Casablanca)",
    metaDescription:
      "Soins infirmiers à domicile Sidi Maarouf, Casablanca. Intervention organisée selon votre besoin, 24h/24 et 7j/7. Appelez SAMUR Casablanca.",
    intro:
      "Sidi Maarouf est un pôle résidentiel et d'affaires du sud de Casablanca. SAMUR Casablanca y propose des soins infirmiers à domicile pour les résidents du quartier.",
    localContext:
      "Sidi Maarouf s'est développé ces dernières années autour de résidences, de bureaux et de commerces, devenant un secteur résidentiel à part entière au sud de Casablanca, aux côtés de quartiers comme Oasis ou Californie.",
    neighboringSlugs: ["californie-casablanca", "oasis-casablanca"],
    practicalInfo:
      "Les interventions à Sidi Maarouf sont organisées après un premier contact téléphonique permettant d'évaluer la demande et la disponibilité.",
  },
];

export function getZoneBySlug(slug: string): Zone | undefined {
  return zones.find((zone) => zone.slug === slug);
}
