import { site } from "@/data/site";

export function FloatingContactButtons() {
  return (
    <div className="fixed bottom-5 right-4 z-50 flex flex-col items-end gap-3 sm:right-6">
      <a
        href={site.whatsapp.href}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={`Contacter SAMUR Casablanca sur WhatsApp au ${site.whatsapp.display}`}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg shadow-black/20 transition-transform hover:scale-105"
      >
        <WhatsAppIcon />
      </a>
      <a
        href={site.phones.mobile.href}
        aria-label={`Appeler SAMUR Casablanca au ${site.phones.mobile.display}`}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-navy-900 text-white shadow-lg shadow-black/20 transition-transform hover:scale-105"
      >
        <PhoneIcon />
      </a>
    </div>
  );
}

function WhatsAppIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor" className="h-7 w-7">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.198.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.873.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
      <path d="M12.004 2C6.486 2 2 6.486 2 12.004c0 1.86.507 3.68 1.47 5.27L2 22l4.86-1.44a9.96 9.96 0 0 0 5.144 1.404h.004c5.518 0 10.004-4.486 10.004-10.004C22.012 6.486 17.522 2 12.004 2zm0 18.09h-.003a8.06 8.06 0 0 1-4.116-1.128l-.295-.176-3.056.905.918-2.98-.192-.306a8.06 8.06 0 0 1-1.24-4.401c0-4.47 3.638-8.108 8.108-8.108a8.06 8.06 0 0 1 5.735 2.373 8.06 8.06 0 0 1 2.373 5.736c0 4.47-3.638 8.085-8.232 8.085z" />
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      className="h-6 w-6"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M2.5 4.5c0-1.1.9-2 2-2h2.153a1 1 0 0 1 .986.836l.58 3.478a1 1 0 0 1-.54 1.06l-1.6.8a12.06 12.06 0 0 0 5.747 5.747l.8-1.6a1 1 0 0 1 1.06-.54l3.478.58a1 1 0 0 1 .836.986V16.5a2 2 0 0 1-2 2h-1c-8 0-14.5-6.5-14.5-14.5v-1Z"
      />
    </svg>
  );
}
