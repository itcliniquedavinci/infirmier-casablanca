import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { FAQAccordion } from "@/components/sections/FAQAccordion";
import { CTASection } from "@/components/sections/CTASection";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema, faqPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { getHubFaqGroups, getHubFaqItems } from "@/data/faqs";

const path = "/faq";
const title = "FAQ — Soins infirmiers à domicile Casablanca";
const description =
  "Questions fréquentes sur les soins infirmiers à domicile Casablanca : infirmier à domicile, prescriptions, disponibilité, tarifs, quartiers et contact.";

export const metadata = buildMetadata({ title, description, path });

const groups = getHubFaqGroups();

export default function FaqPage() {
  return (
    <>
      <JsonLd
        data={[
          webPageSchema({ title, description, path }),
          faqPageSchema(getHubFaqItems()),
        ]}
      />
      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: "FAQ", path }]} />

      <Container className="py-12">
        <div
          aria-hidden="true"
          className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700"
        />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">
          Questions fréquentes
        </h1>
        <p className="mt-4 max-w-2xl text-navy-700">
          Les réponses sont regroupées par thème. Chaque page du site (soins, zones,
          quartiers, contact) présente également sa propre sélection de questions.
        </p>

        <nav aria-label="Thèmes de la FAQ" className="mt-8">
          <ul className="flex flex-wrap gap-2">
            {groups.map((group) => (
              <li key={group.category}>
                <a
                  href={`#faq-${group.category}`}
                  className="inline-block rounded-full border border-surface-gray-dark bg-white px-3 py-1 text-sm text-navy-800 hover:border-brand-green-600 hover:text-brand-green-600"
                >
                  {group.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="mt-12 space-y-12">
          {groups.map((group) => (
            <section key={group.category} id={`faq-${group.category}`} className="scroll-mt-24">
              <h2 className="text-xl font-bold text-navy-950">{group.label}</h2>
              <div className="mt-5">
                <FAQAccordion items={group.items} defaultOpenIndex={null} />
              </div>
            </section>
          ))}
        </div>
      </Container>

      <CTASection />
    </>
  );
}
