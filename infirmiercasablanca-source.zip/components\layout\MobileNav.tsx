"use client";

import { useState } from "react";
import Link from "next/link";
import { site } from "@/data/site";
import { PhoneButton } from "@/components/ui/PhoneButton";

type NavLink = { href: string; label: string };

export function MobileNav({ links }: { links: NavLink[] }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="lg:hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls="mobile-nav-panel"
        aria-label={open ? "Fermer le menu" : "Ouvrir le menu"}
        className="flex h-11 w-11 items-center justify-center rounded-lg border border-surface-gray-dark text-navy-900"
      >
        {open ? (
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 6l12 12M18 6L6 18" />
          </svg>
        ) : (
          <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-6 w-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        )}
      </button>

      {open && (
        <div
          id="mobile-nav-panel"
          className="absolute inset-x-0 top-full border-b border-surface-gray-dark bg-white shadow-lg"
        >
          <nav aria-label="Navigation mobile" className="flex flex-col px-4 py-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setOpen(false)}
                className="border-b border-surface-gray-dark py-3 text-base font-medium text-navy-900 last:border-none"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="flex flex-col gap-3 px-4 pb-6">
            <PhoneButton
              href={site.phones.mobile.href}
              label={`Appeler ${site.phones.mobile.display}`}
              className="w-full"
            />
          </div>
        </div>
      )}
    </div>
  );
}
