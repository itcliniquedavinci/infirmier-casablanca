import Link from "next/link";
import { JsonLd } from "@/components/schema/JsonLd";
import { breadcrumbListSchema } from "@/lib/schema";

export type BreadcrumbItem = {
  name: string;
  path: string;
};

export function Breadcrumbs({ items }: { items: BreadcrumbItem[] }) {
  return (
    <nav aria-label="Fil d'Ariane" className="border-b border-surface-gray-dark bg-surface-gray">
      <div className="mx-auto w-full max-w-6xl px-4 py-3 sm:px-6 lg:px-8">
        <ol className="flex flex-wrap items-center gap-1 text-sm text-navy-700">
          {items.map((item, index) => {
            const isLast = index === items.length - 1;
            return (
              <li key={item.path} className="flex items-center gap-1">
                {index > 0 && <span aria-hidden="true">/</span>}
                {isLast ? (
                  <span aria-current="page" className="font-medium text-navy-900">
                    {item.name}
                  </span>
                ) : (
                  <Link href={item.path} className="hover:text-brand-green-600">
                    {item.name}
                  </Link>
                )}
              </li>
            );
          })}
        </ol>
      </div>
      <JsonLd data={breadcrumbListSchema(items)} />
    </nav>
  );
}
