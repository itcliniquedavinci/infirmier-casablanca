import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { Container } from "@/components/ui/Container";
import { ServiceCard } from "@/components/sections/ServiceCard";
import { ZoneCard } from "@/components/sections/ZoneCard";
import { FAQSection } from "@/components/sections/FAQSection";
import { LocalInfo } from "@/components/sections/LocalInfo";
import { ContactCard } from "@/components/sections/ContactCard";
import { CTASection } from "@/components/sections/CTASection";
import { PhoneButton } from "@/components/ui/PhoneButton";
import { JsonLd } from "@/components/schema/JsonLd";
import { webPageSchema } from "@/lib/schema";
import { buildMetadata } from "@/lib/metadata";
import { services } from "@/data/services";
import { zones } from "@/data/zones";
import { getFaqsForPage } from "@/data/faqs";
import { site } from "@/data/site";

const path = "/infirmier-a-domicile-casablanca";
const title = "Infirmier à domicile Casablanca";
const description =
  "Infirmier à domicile Casablanca : soins infirmiers organisés chez vous, 24h/24 et 7j/7. Fonctionnement, soins disponibles, zones desservies et contact.";

export const metadata = buildMetadata({ title, description, path });

export default function InfirmierADomicileCasablancaPage() {
  return (
    <>
      <JsonLd data={webPageSchema({ title, description, path })} />

      <Breadcrumbs items={[{ name: "Accueil", path: "/" }, { name: title, path }]} />

      <Container className="py-12">
        <div aria-hidden="true" className="mb-4 h-1.5 w-16 rounded-full bg-gradient-to-r from-brand-green-600 to-navy-700" />
        <h1 className="text-3xl font-bold text-navy-950 sm:text-4xl">{title}</h1>
        <p className="mt-4 max-w-2xl text-lg text-navy-700">{description}</p>
        <div className="mt-6">
          <PhoneButton href={site.phones.mobile.href} label={`Appeler ${site.phones.mobile.display}`} />
        </div>
      </Container>

      <section className="bg-surface-gray py-12">
        <Container>
          <h2 className="text-2xl font-bold text-navy-950">
            Soins infirmiers à domicile Casablanca
          </h2>
          <p className="mt-4 max-w-3xl text-navy-700">
            SAMUR Casablanca organise des interventions de soins infirmiers directement au
            domicile des patients à Casablanca. Le service s&apos;adresse aux personnes qui
            souhaitent recevoir des soins infirmiers courants sans se déplacer, dans le cadre
            défini avec l&apos;équipe au moment de la demande.
          </p>
        </Container>
      </section>

      <Container className="py-12">
        <h2 className="text-2xl font-bold text-navy-950">Comment demander une intervention ?</h2>
        <p className="mt-4 max-w-3xl text-navy-700">
          Il suffit de nous contacter par téléphone au {site.phones.mobile.display} ou au{" "}
          {site.phones.landline.display}. Nous échangeons avec vous sur le besoin exprimé, puis
          l&apos;intervention est organisée selon la situation et la disponibilité du service.
        </p>
      </Container>

      <section className="bg-surface-gray py-12">
        <Container>
          <h2 className="text-2xl font-bold text-navy-950">
            Quels soins peuvent être réalisés à domicile ?
          </h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <ServiceCard key={service.slug} service={service} />
            ))}
          </div>
        </Container>
      </section>

      <Container className="py-12">
        <h2 className="text-2xl font-bold text-navy-950">Comment se déroule une intervention ?</h2>
        <p className="mt-4 max-w-3xl text-navy-700">
          Après le premier contact téléphonique, l&apos;intervention est organisée selon le besoin
          exprimé. Le soin est réalisé au domicile du patient, dans le cadre convenu avec vous au
          préalable.
        </p>
      </Container>

      <section className="bg-surface-gray py-12">
        <Container>
          <h2 className="text-2xl font-bold text-navy-950">Disponibilité du service</h2>
          <p className="mt-4 max-w-3xl text-navy-700">
            Le service est annoncé disponible {site.hours.display}. Chaque demande est organisée
            selon la situation et la disponibilité au moment de l&apos;appel.
          </p>
        </Container>
      </section>

      <Container className="py-12">
        <h2 className="text-2xl font-bold text-navy-950">Zones desservies à Casablanca</h2>
        <p className="mt-4 max-w-3xl text-navy-700">
          SAMUR Casablanca intervient à Casablanca, notamment dans les quartiers suivants.
        </p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {zones.map((zone) => (
            <ZoneCard key={zone.slug} zone={zone} />
          ))}
        </div>
      </Container>

      <section className="bg-surface-gray py-12">
        <Container className="grid gap-8 lg:grid-cols-2">
          <LocalInfo />
          <ContactCard />
        </Container>
      </section>

      <FAQSection
        title="Questions fréquentes sur les soins infirmiers à domicile Casablanca"
        intro="Demande d'intervention, déroulement, disponibilité, quartiers desservis et contact : l'essentiel pour organiser un passage infirmier à Casablanca."
        items={getFaqsForPage("pilier")}
        moreHref="/faq"
      />

      <CTASection />
    </>
  );
}
